
import React, { useState, useEffect, useRef } from "react";
import { Participant } from "@/api/entities";
import { Prize } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Sparkles, Play, RotateCcw, Trophy, Users, Gift, Volume2, VolumeX, Shuffle, Filter, Loader2, Edit3 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import DrawWheel from "../components/draw/DrawWheel";
import DrawSetup from "../components/draw/DrawSetup";
import DrawResults from "../components/draw/DrawResults";
import DrawSettingsModal from "../components/draw/DrawSettingsModal";

// צליל שעון עצר משופר
const playTickingClockSound = (intensity = 0, isFinalTicks = false) => {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    let frequency, duration, volume;

    if (isFinalTicks) {
      frequency = 2500; // תדירות גבוהה יותר לסיום
      duration = 0.03; // טיקים קצרים ומהירים
      volume = 0.3;
    } else {
      frequency = 1500; // תדירות קבועה למהלך ההגרלה
      duration = 0.08; // משך קבוע
      volume = 0.15; // עוצמה קבועה
    }
    
    osc.frequency.value = frequency;
    osc.type = 'square'; // צליל טיק חד
    
    gain.gain.setValueAtTime(volume, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    
    osc.start();
    osc.stop(ctx.currentTime + duration);
    
    setTimeout(() => ctx.close(), duration * 1000 + 50);
  } catch (e) {
    console.warn("Could not play ticking clock sound");
  }
};

// פנפרה לסיום (בלי מחיאות כפיים)
const playFinalFanfare = () => {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    
    const notes = [
      { freq: 659, time: 0, duration: 0.2 },  // E5
      { freq: 784, time: 0.15, duration: 0.25 }, // G5
      { freq: 1047, time: 0.35, duration: 0.4 }, // C6 - צליל סיום
    ];
    
    notes.forEach((note, index) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.frequency.value = note.freq;
      osc.type = 'triangle'; // צליל נעים יותר
      
      const startTime = ctx.currentTime + note.time;
      const endTime = startTime + note.duration;
      const volume = 0.2 + (index * 0.05);
      
      gain.gain.setValueAtTime(0, startTime);
      gain.gain.linearRampToValueAtTime(volume, startTime + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, endTime);
      
      osc.start(startTime);
      osc.stop(endTime);
    });
    
    setTimeout(() => ctx.close(), 1000);
  } catch (e) {
    console.warn("Could not play final fanfare");
  }
};


const shuffleArray = (array) => {
  let currentIndex = array.length, randomIndex;
  while (currentIndex !== 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;
    [array[currentIndex], array[randomIndex]] = [
      array[randomIndex], array[currentIndex]];
  }
  return array;
};

// Helper function to get names for the wheel effect
const getWheelNamesList = (participants, minLength = 50) => {
  if (!participants || participants.length === 0) return ["..."];
  if (participants.length >= minLength) return shuffleArray([...participants.map(p => p.name)]);
  
  let wheelNamesArr = [];
  while (wheelNamesArr.length < minLength) {
    wheelNamesArr = wheelNamesArr.concat(shuffleArray([...participants.map(p => p.name)]));
  }
  return wheelNamesArr.slice(0, minLength + Math.floor(Math.random() * 20));
};


export default function DrawPage() {
  const [allParticipants, setAllParticipants] = useState([]);
  const [availableParticipantsForDraw, setAvailableParticipantsForDraw] = useState([]);
  const [prizes, setPrizes] = useState([]);
  const [selectedPrize, setSelectedPrize] = useState(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [winner, setWinner] = useState(null);
  const [drawHistory, setDrawHistory] = useState([]);
  const [drawDuration, setDrawDuration] = useState(15000);
  const [isMuted, setIsMuted] = useState(false);
  const [participantGroups, setParticipantGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("all");
  const [showOnlyUndrawnGroups, setShowOnlyUndrawnGroups] = useState(false); // New state
  const [participantsAvailableForAdditionalDrawCount, setParticipantsAvailableForAdditionalDrawCount] = useState(0);
  const [audioReady, setAudioReady] = useState(false);
  const [drawIntensity, setDrawIntensity] = useState(0);
  const [drawTitle, setDrawTitle] = useState("הגרלה מיוחדת");
  const [logoUrl, setLogoUrl] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const [tickInterval, setTickInterval] = useState(null);
  
  // New state for display names (array of 8)
  const [displayNames, setDisplayNames] = useState(["...", "...", "...", "...", "...", "...", "...", "..."]);
  const [nameDisplayInterval, setNameDisplayInterval] = useState(null);
  const wheelNamesRef = useRef([]); // To store the list of names for the wheel effect


  useEffect(() => {
    // Load from LocalStorage on initial mount
    const savedTitle = localStorage.getItem("drawTitle");
    const savedLogoUrl = localStorage.getItem("logoUrl");
    if (savedTitle) setDrawTitle(savedTitle);
    if (savedLogoUrl) setLogoUrl(savedLogoUrl);
    
    // בדיקה פשוטה אם אודיו עובד
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) {
        const testCtx = new AudioContext();
        testCtx.close();
        setAudioReady(true);
      } else {
        console.warn("Web Audio API not supported");
        setAudioReady(false);
      }
    } catch (e) {
      console.warn("Error checking AudioContext:", e);
      setAudioReady(false);
    }

    loadData();

    return () => {
      if (tickInterval) clearInterval(tickInterval);
      if (nameDisplayInterval) clearInterval(nameDisplayInterval);
    };
  }, []);

  // Save to LocalStorage whenever drawTitle or logoUrl changes
  useEffect(() => {
    localStorage.setItem("drawTitle", drawTitle);
  }, [drawTitle]);

  useEffect(() => {
    localStorage.setItem("logoUrl", logoUrl);
  }, [logoUrl]);
  
  const loadPrizesAndSetSelected = async (prizeToSelectAfterLoad = null) => {
    const prizesData = await Prize.list("-created_date");
    setPrizes(prizesData);
    if (prizeToSelectAfterLoad) {
      const reloadedPrize = prizesData.find(p => p.id === prizeToSelectAfterLoad.id);
      setSelectedPrize(reloadedPrize || prizeToSelectAfterLoad); 
    }
    return prizesData;
  };

  const loadData = async () => {
    const [participantsData, prizesData] = await Promise.all([
      Participant.list(),
      Prize.list("-created_date")
    ]);

    const activeParticipants = participantsData.filter(p => p.active);
    setAllParticipants(activeParticipants);
    setPrizes(prizesData);

    const uniqueGroups = [...new Set(activeParticipants.map(p => p.group_name).filter(Boolean))].sort();
    setParticipantGroups(uniqueGroups);

    // Initial filtering after data load (will also be handled by useEffect below)
    filterAvailableParticipants(activeParticipants, selectedGroup, drawHistory);
    setDisplayNames(["...", "...", "...", "...", "...", "...", "...", "..."]); // Reset display names on new data load
  };

  const filterAvailableParticipants = (participantsToFilter, group, currentDrawHistory) => {
    let filtered = participantsToFilter;
    if (group !== "all") {
      // Handle "ללא קבוצה" specifically as group_name might be null/undefined or empty string
      if (group === "ללא קבוצה") {
        filtered = filtered.filter(p => !p.group_name || p.group_name.trim() === "");
      } else {
        filtered = filtered.filter(p => p.group_name === group);
      }
    }
    const winnersSoFar = currentDrawHistory.map(h => h.participant.id); // Ensure participant.id is used as drawHistory stores full participant object
    filtered = filtered.filter(p => !winnersSoFar.includes(p.id));
    setAvailableParticipantsForDraw(filtered);
    setParticipantsAvailableForAdditionalDrawCount(filtered.length); // Update count for "additional draw" button
  };

  useEffect(() => {
    filterAvailableParticipants(allParticipants, selectedGroup, drawHistory);
  }, [allParticipants, selectedGroup, drawHistory]);
  
  const executeDrawProcess = async (prizeToDrawFor, isInitialDraw) => {
    setIsDrawing(true);
    setDrawIntensity(0);
    setDisplayNames(["...", "...", "...", "...", "...", "...", "...", "..."]); // Reset display names at start of draw

    // Prepare wheel names
    wheelNamesRef.current = getWheelNamesList(availableParticipantsForDraw);
    let currentNameIndex = 0;

    let intensityInterval;
    let currentTickInterval = null;
    let currentNameDisplayInterval = null;

    // Start name display interval immediately with constant fast speed
    if (wheelNamesRef.current.length > 0) {
      // Set initial names immediately
      const initialNames = [
        wheelNamesRef.current[0 % wheelNamesRef.current.length],
        wheelNamesRef.current[1 % wheelNamesRef.current.length],
        wheelNamesRef.current[2 % wheelNamesRef.current.length],
        wheelNamesRef.current[3 % wheelNamesRef.current.length],
        wheelNamesRef.current[4 % wheelNamesRef.current.length],
        wheelNamesRef.current[5 % wheelNamesRef.current.length],
        wheelNamesRef.current[6 % wheelNamesRef.current.length],
        wheelNamesRef.current[7 % wheelNamesRef.current.length]
      ];
      setDisplayNames(initialNames);
      
      currentNameDisplayInterval = setInterval(() => {
        currentNameIndex = (currentNameIndex + 1) % wheelNamesRef.current.length;
        const newNames = [
          wheelNamesRef.current[(currentNameIndex + 0) % wheelNamesRef.current.length],
          wheelNamesRef.current[(currentNameIndex + 1) % wheelNamesRef.current.length],
          wheelNamesRef.current[(currentNameIndex + 2) % wheelNamesRef.current.length],
          wheelNamesRef.current[(currentNameIndex + 3) % wheelNamesRef.current.length],
          wheelNamesRef.current[(currentNameIndex + 4) % wheelNamesRef.current.length],
          wheelNamesRef.current[(currentNameIndex + 5) % wheelNamesRef.current.length],
          wheelNamesRef.current[(currentNameIndex + 6) % wheelNamesRef.current.length],
          wheelNamesRef.current[(currentNameIndex + 7) % wheelNamesRef.current.length]
        ];
        setDisplayNames(newNames);
      }, 80); // Constant fast speed throughout
      setNameDisplayInterval(currentNameDisplayInterval);
    }


    if (!isMuted && audioReady) {
      // טיקים רגילים בקצב קבוע
      currentTickInterval = setInterval(() => {
        playTickingClockSound(0, false); // תמיד תו קבוע
      }, 180); // קצב קבוע
      setTickInterval(currentTickInterval);
    }

    // עדכון עוצמה
    intensityInterval = setInterval(() => {
      setDrawIntensity(prev => Math.min(prev + (50 / drawDuration), 1));
    }, 50);

    // חישוב מתי להתחיל עם הפעימות המהירות (20% לפני הסוף)
    const fastTicksStartTime = drawDuration * 0.8;
    const fastTicksDuration = drawDuration * 0.2; // 20% מהזמן לפעימות מהירות

    // הפעלת הפעימות המהירות במועד הנכון
    setTimeout(async () => { // This timeout is for the fast ticks phase
      if (currentTickInterval) {
        clearInterval(currentTickInterval);
        setTickInterval(null); // Clear the regular tick interval
      }

      // פעימות מהירות לאורך הזמן שנותר
      if (!isMuted && audioReady) {
        const fastTickIntervalMs = 60; // טיק כל 60ms
        const numFastTicks = Math.floor(fastTicksDuration / fastTickIntervalMs);
        
        for (let i = 0; i < numFastTicks; i++) {
          await new Promise(resolve => setTimeout(resolve, fastTickIntervalMs));
          playTickingClockSound(1, true); // טיקים מהירים
        }
      } else {
        // אם אין אודיו, פשוט נחכה את הזמן
        await new Promise(resolve => setTimeout(resolve, fastTicksDuration));
      }
    }, fastTicksStartTime);

    // סיום ההגרלה בזמן המדויק
    setTimeout(async () => { // This is the main timeout for ending the draw
      if (currentTickInterval) clearInterval(currentTickInterval); // Ensure cleaned up if not already
      if (intensityInterval) clearInterval(intensityInterval);
      if (currentNameDisplayInterval) clearInterval(currentNameDisplayInterval); // Stop name cycling

      setTickInterval(null);
      setNameDisplayInterval(null);
      setDrawIntensity(1);

      if (!availableParticipantsForDraw || availableParticipantsForDraw.length === 0) {
        setIsDrawing(false);
        setDisplayNames(["אין זמינים", "", "", "", "", "", "", ""]); // Update for array
        alert("שגיאה: אין משתתפים זמינים להגרלה זו.");
        return;
      }

      const newWinnerParticipant = availableParticipantsForDraw[Math.floor(Math.random() * availableParticipantsForDraw.length)];
      setWinner(newWinnerParticipant);
      setDisplayNames([newWinnerParticipant.name, "", "", "", "", "", "", ""]); // Set final winner name in first position, clear others
      setIsDrawing(false);

      // פנפרה לסיום
      if (!isMuted && audioReady) {
        playFinalFanfare();
      }

      let actualPrizeWon;
      if (isInitialDraw) {
        await Prize.update(prizeToDrawFor.id, {
          winner_id: newWinnerParticipant.id,
          winner_name: newWinnerParticipant.name,
          drawn: true
        });
        actualPrizeWon = { ...prizeToDrawFor, winner_id: newWinnerParticipant.id, winner_name: newWinnerParticipant.name, drawn: true };
      } else {
        const newPrizeData = {
          name: prizeToDrawFor.name, description: prizeToDrawFor.description, value: prizeToDrawFor.value,
          image_url: prizeToDrawFor.image_url, winner_id: newWinnerParticipant.id,
          winner_name: newWinnerParticipant.name, drawn: true
        };
        const createdPrize = await Prize.create(newPrizeData);
        actualPrizeWon = createdPrize;
      }

      const newDrawEntry = {
        prize: actualPrizeWon, participant: newWinnerParticipant,
        participant_id: newWinnerParticipant.id, timestamp: new Date()
      };
      setDrawHistory(prev => [newDrawEntry, ...prev]);

      await loadPrizesAndSetSelected(isInitialDraw ? actualPrizeWon : prizeToDrawFor);
    }, drawDuration); // הסיום בזמן המדויק של משך ההגרלה
  };
  
  // New function to get filtered groups based on showOnlyUndrawnGroups
  const getFilteredGroups = () => {
    if (!showOnlyUndrawnGroups) {
      return participantGroups; // Return all groups
    }

    // Get groups that have already been drawn
    const drawnGroups = new Set();
    prizes.forEach(prize => {
      if (prize.drawn && prize.winner_id) {
        const winnerParticipant = allParticipants.find(p => p.id === prize.winner_id);
        if (winnerParticipant && winnerParticipant.group_name) {
          drawnGroups.add(winnerParticipant.group_name);
        }
      }
    });

    // Return only groups that haven't been drawn
    return participantGroups.filter(group => !drawnGroups.has(group));
  };

  const handleStartDraw = () => {
    if (!selectedPrize || selectedPrize.drawn || availableParticipantsForDraw.length === 0) {
      return;
    }
    
    // אם צריך להפעיל אודיו - נסה עם לחיצה ראשונה
    if (audioReady) {
      try {
        // ניסיון להפעיל אודיו פשוט כדי לקבל אישור מהדפדפן
        playTickingClockSound();
      } catch (e) {
        console.warn("Audio might be blocked:", e);
      }
    }
    
    setWinner(null);
    executeDrawProcess(selectedPrize, true);
  };

  const handleStartAdditionalDraw = () => {
    if (!selectedPrize || availableParticipantsForDraw.length === 0) {
      return;
    }
    if (participantsAvailableForAdditionalDrawCount === 0) { // Use the specific count
      alert(`אין משתתפים נוספים שזמינים להגרלה על פרס "${selectedPrize.name}".`);
      return;
    }
    setWinner(null);
    executeDrawProcess(selectedPrize, false);
  };

  const handleNewDraw = () => {
    setSelectedPrize(null);
    setWinner(null);
    setDrawIntensity(0);
    if (tickInterval) {
      clearInterval(tickInterval);
      setTickInterval(null);
    }
    if (nameDisplayInterval) {
      clearInterval(nameDisplayInterval);
      setNameDisplayInterval(null);
    }
    setDisplayNames(["...", "...", "...", "...", "...", "...", "...", "..."]); // Reset display names
    loadData(); // Reload all data, including participants and prizes
    setSelectedGroup("all"); // Reset group filter
    setDrawHistory([]); // Optionally clear history or persist as needed
  };

  const toggleMute = () => {
    setIsMuted(prev => {
      // אם משתיקים באמצע הגרלה, עוצרים את הצלילים
      if (!prev && tickInterval) { // If it was NOT muted (i.e., we are about to mute it) AND drumroll is active
        clearInterval(tickInterval);
        setTickInterval(null);
      }
      return !prev;
    });
  };

  const handleShuffleParticipants = () => {
    setAvailableParticipantsForDraw(prev => shuffleArray([...prev]));
  };

  const handleGroupChange = (newGroup) => {
    setSelectedGroup(newGroup);
    setWinner(null); // Reset winner if group changes
    setDisplayNames(["...", "...", "...", "...", "...", "...", "...", "..."]); // Reset display names on group change
    // Filtering is handled by useEffect
  };

  const availablePrizesForSelection = prizes.filter(p => !p.drawn);
  const filteredGroups = getFilteredGroups(); // Get filtered groups

  return (
    <div className="space-y-6">
      {/* Header */}
      <div
        className="glass-card p-6 shadow-lg relative overflow-hidden" 
      >
        {isDrawing && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0">
            {Array.from({length: 20}).map((_, i) => (
              <motion.div
                key={i}
                className="absolute rounded-full bg-amber-400 dark:bg-amber-500"
                initial={{ opacity: 0, scale: 0 }}
                animate={{
                  opacity: [0, 0.7, 0],
                  scale: [0, 1 + Math.random() * 2, 0],
                  x: (Math.random() - 0.5) * 600,
                  y: (Math.random() - 0.5) * 300,
                }}
                transition={{
                  duration: 1 + Math.random() * 2,
                  repeat: Infinity,
                  delay: Math.random() * 1,
                }}
                style={{
                  width: `${5 + Math.random() * 15}px`,
                  height: `${5 + Math.random() * 15}px`,
                }}
              />
            ))}
          </div>
        )}
        <div className="text-center relative z-10">
          {/* לוגו אם קיים */}
          {logoUrl && (
            <div className="mb-4">
              <img
                src={logoUrl}
                alt="לוגו הגרלה"
                className="w-20 h-20 sm:w-24 sm:h-24 object-contain mx-auto rounded-lg shadow-md"
                onError={(e) => {
                  console.error("Error loading logo:", e);
                  setLogoUrl(""); // הסר לוגo אם יש שגיאה בטעינה
                }}
              />
            </div>
          )}

          <motion.div
             animate={{
              scale: isDrawing ? 1 + (drawIntensity * 0.15) : 1,
              rotate: isDrawing ? drawIntensity * 20 : 0
            }}
            transition={{ type: "spring", stiffness: 200, damping: 15 }}
            className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-700 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg"
          >
            <Sparkles className="w-8 h-8 text-white sparkle-effect" />
          </motion.div>

          {/* שם ההגרלה עם אפשרות עריכה */}
          <div className="flex items-center justify-center gap-2 mb-2">
            <h1 className="text-3xl font-bold text-slate-800 dark:text-white">{drawTitle}</h1>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowSettings(true)}
              className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 w-8 h-8"
              disabled={isDrawing}
            >
              <Edit3 className="w-4 h-4" />
            </Button>
          </div>

          <p className="text-slate-600 dark:text-slate-400">
            {availablePrizesForSelection.length} פרסים ממתינים להגרלה • {availableParticipantsForDraw.length} משתתפים זמינים {selectedGroup !== "all" ? `מקבוצת "${selectedGroup}"` : ""}
          </p>
          {!audioReady && !isMuted && (
            <p className="text-xs text-orange-500 dark:text-orange-400 mt-1">⚠️ ייתכן שהשמע לא יפעל כראוי עד לטעינה מלאה (נדרש אינטראקציה ראשונית).</p>
          )}
          {/* אין מד התקדמות ב-Header */}
        </div>
      </div>

      {/* הוספת modal הגדרות */}
      <AnimatePresence>
        {showSettings && (
          <DrawSettingsModal
            drawTitle={drawTitle}
            setDrawTitle={setDrawTitle} // Pass setter directly
            logoUrl={logoUrl}
            setLogoUrl={setLogoUrl} // Pass setter directly
            onClose={() => setShowSettings(false)}
          />
        )}
      </AnimatePresence>

      {/* Participant Group Filter */}
      <div className="glass-card p-4 shadow-md">
        <div className="flex flex-col gap-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:gap-3">
            <Label htmlFor="group_filter" className="text-slate-700 dark:text-slate-300 font-medium flex items-center gap-1.5 whitespace-nowrap">
              <Filter className="w-4 h-4" />
              סנן לפי קבוצה:
            </Label>
            <Select value={selectedGroup} onValueChange={handleGroupChange} disabled={isDrawing || !!winner}>
              <SelectTrigger className="w-full sm:w-auto min-w-[180px] dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200">
                <SelectValue placeholder="בחר קבוצה..." />
              </SelectTrigger>
              <SelectContent className="dark:bg-slate-800 dark:border-slate-700">
                <SelectItem value="all" className="dark:focus:bg-slate-700">כל הקבוצות / ללא קבוצה</SelectItem>
                {filteredGroups.map(group => (
                  <SelectItem key={group} value={group} className="dark:focus:bg-slate-700">{group}</SelectItem>
                ))}
                {/* Added "ללא קבוצה" option for participants without a group name */}
                {allParticipants.some(p => (!p.group_name || p.group_name.trim() === "") && p.active) && (
                  <SelectItem value="ללא קבוצה" className="dark:focus:bg-slate-700">ללא קבוצה</SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>

          {/* New checkbox for filtering undrawn groups */}
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="show-only-undrawn-groups"
              checked={showOnlyUndrawnGroups}
              onChange={(e) => {
                setShowOnlyUndrawnGroups(e.target.checked);
                // Reset to "all" when toggling filter
                if (e.target.checked) {
                  setSelectedGroup("all");
                }
              }}
              disabled={isDrawing || !!winner}
              className="rounded text-blue-600 focus:ring-blue-500 dark:bg-slate-700 dark:border-slate-600"
            />
            <Label 
              htmlFor="show-only-undrawn-groups" 
              className="text-sm text-slate-700 dark:text-slate-300 cursor-pointer"
            >
              הצג רק קבוצות שעוד לא הוגרלו ({filteredGroups.length} מתוך {participantGroups.length})
            </Label>
          </div>

          {/* Information about filtered groups */}
          {showOnlyUndrawnGroups && filteredGroups.length < participantGroups.length && (
            <div className="p-3 bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 rounded-lg">
              <p className="text-sm text-blue-700 dark:text-blue-300">
                מוצגות {filteredGroups.length} קבוצות שעוד לא הוגרלו מתוך {participantGroups.length} קבוצות סה"כ.
                {filteredGroups.length === 0 && " כל הקבוצות כבר הוגרלו!"}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Draw Interface */}
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-6">
          <DrawSetup
            prizesForSelection={availablePrizesForSelection}
            selectedPrize={selectedPrize}
            onSelectPrize={(prize) => { setSelectedPrize(prize); setWinner(null); setDisplayNames(["...", "...", "...", "...", "...", "...", "...", "..."]); }}
            participantsCount={availableParticipantsForDraw.length}
            isDrawing={isDrawing}
            onStartDraw={handleStartDraw}
            onStartAdditionalDraw={handleStartAdditionalDraw}
            onNewDraw={handleNewDraw}
            winner={winner}
            drawDuration={drawDuration}
            setDrawDuration={setDrawDuration}
            isMuted={isMuted}
            toggleMute={toggleMute}
            onShuffleParticipants={handleShuffleParticipants}
            selectedGroup={selectedGroup}
            participantsAvailableForAdditionalDrawCount={participantsAvailableForAdditionalDrawCount}
            audioReady={audioReady}
          />

          {drawHistory.length > 0 && (
            <DrawResults drawHistory={drawHistory} />
          )}
        </div>

        <div className="lg:col-span-2 space-y-4">
          {/* Participants List - Now above the draw wheel */}
          {!isDrawing && !winner && availableParticipantsForDraw.length > 0 && (
            <div className="glass-card p-4 shadow-md">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-2">
                  <Users className="w-5 h-5 text-blue-500 dark:text-blue-400" />
                  משתתפים זמינים ({availableParticipantsForDraw.length})
                </h3>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleShuffleParticipants}
                  disabled={isDrawing || !!winner || availableParticipantsForDraw.length === 0}
                  className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
                >
                  <Shuffle className="w-4 h-4 mr-1" />
                  ערבב
                </Button>
              </div>
              
              {/* Horizontal grid layout for participants */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 max-h-32 overflow-y-auto">
                {availableParticipantsForDraw.slice(0, 12).map((participant, index) => (
                  <motion.div
                    key={participant.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.03 }}
                    className="flex flex-col items-center p-2 bg-slate-50 dark:bg-slate-700/50 rounded-md border border-slate-200 dark:border-slate-600/50 min-h-[60px]"
                  >
                    <div className="w-6 h-6 bg-blue-100 dark:bg-blue-800/50 rounded-full flex items-center justify-center text-xs font-medium text-blue-600 dark:text-blue-300 mb-1">
                      {index + 1}
                    </div>
                    <span className="text-xs font-medium text-slate-700 dark:text-slate-200 text-center truncate w-full" title={participant.name}>
                      {participant.name}
                    </span>
                    {participant.group_name && selectedGroup === "all" && (
                      <span className="text-xs text-slate-500 dark:text-slate-400 bg-slate-200 dark:bg-slate-600 px-1 py-0.5 rounded mt-1 truncate w-full text-center" title={participant.group_name}>
                        {participant.group_name}
                      </span>
                    )}
                  </motion.div>
                ))}
                
                {availableParticipantsForDraw.length > 12 && (
                  <div className="flex items-center justify-center p-2 text-xs text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-700/30 rounded-md border border-slate-200 dark:border-slate-600/50 min-h-[60px]">
                    <div className="text-center">
                      <div className="text-lg font-bold">+{availableParticipantsForDraw.length - 12}</div>
                      <div>נוספים</div>
                    </div>
                  </div>
                )}
              </div>
              
              {availableParticipantsForDraw.length === 0 && (
                <div className="text-center p-4 text-sm text-slate-500 dark:text-slate-400">
                  אין משתתפים זמינים {selectedGroup !== "all" ? `בקבוצת "${selectedGroup}"` : ""}
                </div>
              )}
            </div>
          )}

          <DrawWheel
            participants={availableParticipantsForDraw}
            isDrawing={isDrawing}
            winner={winner}
            selectedPrize={selectedPrize}
            drawIntensity={drawIntensity}
            displayNames={displayNames}
            drawDuration={drawDuration}
          />
        </div>
      </div>

      {/* Stats */}
      <div className="grid md:grid-cols-3 gap-4 sm:gap-6">
        {[
          { icon: Users, label: `משתתפים זמינים ${selectedGroup !== "all" ? `ב"${selectedGroup}"` : ""}`, value: availableParticipantsForDraw.length, color: "blue" },
          { icon: Gift, label: "פרסים (ייחודיים) שטרם הוגרלו", value: availablePrizesForSelection.length, color: "amber" },
          { icon: Trophy, label: "הגרלות (זכיות) בוצעו בסך הכל", value: drawHistory.length, color: "green" },
        ].map(stat => (
          <motion.div
            key={stat.label}
            initial={{ opacity:0, y:15}}
            animate={{ opacity:1, y:0}}
            transition={{ delay: 0.1 + Math.random()*0.2 }}
            className="glass-card p-4 sm:p-5 text-center shadow-md"
          >
            <stat.icon className={`w-7 h-7 sm:w-8 sm:h-8 text-${stat.color}-500 dark:text-${stat.color}-400 mx-auto mb-2`} />
            <div className="text-xl sm:text-2xl font-bold text-slate-800 dark:text-white">{stat.value}</div>
            <div className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">{stat.label}</div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
