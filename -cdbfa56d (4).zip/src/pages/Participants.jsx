
import React, { useState, useEffect, useRef } from "react";
import { Participant } from "@/api/entities";
import { Prize } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Users, Upload, Plus, Search, Download, ClipboardPaste, RotateCcw, Edit3, UserPlus, Loader2, Trash2, Filter, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

import ParticipantImport from "../components/participants/ParticipantImport";
import ParticipantList from "../components/participants/ParticipantList";
import ParticipantForm from "../components/participants/ParticipantForm";
import ParticipantPasteImport from "../components/participants/ParticipantPasteImport";
import GroupEditModal from "../components/participants/GroupEditModal";
import NoGroupAssignModal from "../components/participants/NoGroupAssignModal";

// The ImportProgressBar component is removed as it's no longer needed for bulk import.

export default function ParticipantsPage() {
  const [allParticipantsData, setAllParticipantsData] = useState([]);
  const [drawnPrizes, setDrawnPrizes] = useState([]);
  const [showImport, setShowImport] = useState(false);
  const [showPasteImport, setShowPasteImport] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editingParticipant, setEditingParticipant] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [selectedGroup, setSelectedGroup] = useState("הכל");
  const [showGroupEditModal, setShowGroupEditModal] = useState(false);
  const [groupToEdit, setGroupToEdit] = useState(null);
  const [showNoGroupAssignModal, setShowNoGroupAssignModal] = useState(false);
  const [isSubmittingGroupAction, setIsSubmittingGroupAction] = useState(false);
  const [selectedParticipants, setSelectedParticipants] = useState(new Set());
  
  // backgroundImport and abortImportControllerRef states are removed.

  const [advancedFilters, setAdvancedFilters] = useState({
    showGroupsNotDrawn: false,
    showGroupsDrawn: false,
    showActiveOnly: false,
    showInactiveOnly: false
  });

  const loadParticipantsAndPrizes = async () => {
    setIsLoading(true);
    try {
      const [participantsData, prizesData] = await Promise.all([
        Participant.list("-created_date"),
        Prize.filter({ drawn: true })
      ]);
      setAllParticipantsData(participantsData);
      setDrawnPrizes(prizesData);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  
  useEffect(() => {
    loadParticipantsAndPrizes();
  }, []);

  // handleStartImport and cancelImport are no longer needed as import logic moves to components.

  const getGroupTabs = (data) => {
    const groups = [...new Set(data.map(p => p.group_name || "ללא קבוצה"))];
    const groupCounts = {};
    data.forEach(p => {
      const groupKey = p.group_name || "ללא קבוצה";
      groupCounts[groupKey] = (groupCounts[groupKey] || 0) + 1;
    });
    return [
      { name: "הכל", count: data.length },
      ...groups.sort().map(group => ({ name: group, count: groupCounts[group] || 0 }))
    ];
  };

  const getFilteredParticipants = (data, group, term, filters, drawnPrizesData) => {
    let filtered = data;
    if (group !== "הכל") {
      filtered = filtered.filter(p => (p.group_name || "ללא קבוצה") === group);
    }
    if (term) {
      filtered = filtered.filter(p =>
        p.name.toLowerCase().includes(term.toLowerCase()) ||
        (p.email && p.email.toLowerCase().includes(term.toLowerCase())) ||
        (p.phone && p.phone.toLowerCase().includes(term.toLowerCase())) ||
        (p.group_name && p.group_name.toLowerCase().includes(term.toLowerCase()))
      );
    }
    
    if (filters.showActiveOnly && !filters.showInactiveOnly) {
      filtered = filtered.filter(p => p.active);
    } else if (filters.showInactiveOnly && !filters.showActiveOnly) {
      filtered = filtered.filter(p => !p.active);
    }

    if (filters.showGroupsDrawn && !filters.showGroupsNotDrawn) {
      const drawnGroupNames = new Set(drawnPrizesData.map(prize => {
        const participant = data.find(p => p.id === prize.winner_id);
        return participant?.group_name;
      }).filter(Boolean));
      filtered = filtered.filter(p => p.group_name && drawnGroupNames.has(p.group_name));
    } else if (filters.showGroupsNotDrawn && !filters.showGroupsDrawn) {
      const drawnGroupNames = new Set(drawnPrizesData.map(prize => {
        const participant = data.find(p => p.id === prize.winner_id);
        return participant?.group_name;
      }).filter(Boolean));
      filtered = filtered.filter(p => !p.group_name || !drawnGroupNames.has(p.group_name));
    }
    
    return filtered;
  };

  const handleSaveParticipant = async (participantData) => {
    setIsSubmittingGroupAction(true);
    try {
      if (editingParticipant) {
        await Participant.update(editingParticipant.id, participantData);
      } else {
        await Participant.create(participantData);
      }
    } catch (error) {
      console.error("Error saving participant:", error);
      alert("שגיאה בשמירת המשתתף. אנא נסה שוב.");
    } finally {
      setShowForm(false);
      setEditingParticipant(null);
      await loadParticipantsAndPrizes();
      setIsSubmittingGroupAction(false);
    }
  };

  const handleEditParticipant = (participant) => {
    setEditingParticipant(participant);
    setShowForm(true);
  };

  const handleDeleteParticipant = async (participantId) => {
    setIsSubmittingGroupAction(true);
    try {
      await Participant.delete(participantId);
    } catch (error) {
      console.error("Error deleting participant:", error);
      alert("שגיאה במחיקת המשתתף. אנא נסה שוב.");
    } finally {
      await loadParticipantsAndPrizes();
      setIsSubmittingGroupAction(false);
    }
  };
  
  const exportParticipants = () => {
    const csvData = allParticipantsData.map(p => ({
      'שם': p.name,
      'מייל': p.email || '',
      'טלפון': p.phone || '',
      'קבוצה': p.group_name || '',
      'פעיל': p.active ? 'כן' : 'לא'
    }));

    if (csvData.length === 0) {
        alert("אין נתונים לייצוא.");
        return;
    }

    const headers = Object.keys(csvData[0]);
    const csvContent = [
      headers.join(','),
      ...csvData.map(row => headers.map(header => {
        const value = row[header];
        return `"${String(value).replace(/"/g, '""')}"`;
      }).join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.ObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'participants.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const resetParticipants = async () => {
    if (window.confirm("האם אתה בטוח שברצונך למחוק את כל המשתתפים? לא ניתן לשחזר פעולה זו.")) {
      setIsSubmittingGroupAction(true);
      
      try {
        const currentParticipants = [...allParticipantsData];
        let successCount = 0;
        let errorCount = 0;
        
        const batchSize = 5; // Reduced batch size
        const delayBetweenBatches = 2000; // Increased delay
        
        for (let i = 0; i < currentParticipants.length; i += batchSize) {
          const batch = currentParticipants.slice(i, i + batchSize);
          const promises = batch.map(participant => {
            return Participant.delete(participant.id)
              .then(() => {
                successCount++;
              })
              .catch(singleError => {
                errorCount++;
                console.error(`Error deleting participant ID: ${participant.id}`, singleError);
              });
          });
          
          await Promise.all(promises);
          
          if (i + batchSize < currentParticipants.length) {
            await new Promise(resolve => setTimeout(resolve, delayBetweenBatches));
          }
        }
        
        if (errorCount > 0) {
          alert(`איפוס הושלם חלקית. ${successCount} משתתפים נמחקו, ${errorCount} נכשלו.`);
        }
        
      } catch (error) {
        console.error("Error resetting participants:", error);
        alert("שגיאה באיפוס רשימת המשתתפים.");
      } finally {
        await loadParticipantsAndPrizes();
        setIsSubmittingGroupAction(false);
      }
    }
  };

  const deleteAllNoGroupParticipants = async () => {
    const noGroupParticipants = allParticipantsData.filter(p => !p.group_name);
    if (noGroupParticipants.length === 0) {
      alert("אין משתתפים ללא קבוצה למחיקה.");
      return;
    }

    if (window.confirm(`האם אתה בטוח שברצונך למחוק את כל ${noGroupParticipants.length} המשתתפים ללא קבוצה? לא ניתן לשחזר פעולה זו.`)) {
      setIsSubmittingGroupAction(true);
      let successCount = 0;
      let errorCount = 0;

      try {
        const batchSize = 5;
        const delay = 1000;
        
        for (let i = 0; i < noGroupParticipants.length; i += batchSize) {
          const batch = noGroupParticipants.slice(i, i + batchSize);
          const promises = batch.map(participant => {
            return Participant.delete(participant.id)
              .then(() => {
                successCount++;
                return Promise.resolve();
              })
              .catch(singleError => {
                errorCount++;
                console.error(`Error deleting participant ID: ${participant.id}`, singleError);
                return Promise.resolve();
              });
          });
          
          await Promise.all(promises);
          
          if (i + batchSize < noGroupParticipants.length) {
            await new Promise(resolve => setTimeout(resolve, delay));
          }
        }

        if (errorCount > 0) {
          alert(`מחיקה הושלמה חלקית. ${successCount} משתתפים נמחקו, ${errorCount} נכשלו.`);
        } else {
          alert(`מחיקה הושלמה בהצלחה. כל ${successCount} המשתתפים נמחקו.`);
        }

        await loadParticipantsAndPrizes();
        setSelectedGroup("הכל");
      } catch (error) {
        console.error("Error in bulk delete process:", error);
        alert("שגיאה כללית במחיקת המשתתפים ללא קבוצה.");
      } finally {
        setIsSubmittingGroupAction(false);
      }
    }
  };

  const deleteSelectedParticipants = async () => {
    if (selectedParticipants.size === 0) {
      alert("לא נבחרו משתתפים למחיקה.");
      return;
    }

    const participantsToDelete = allParticipantsData.filter(p => selectedParticipants.has(p.id));
    if (window.confirm(`האם אתה בטוח שברצונך למחוק את ${participantsToDelete.length} המשתתפים שנבחרו? לא ניתן לשחזר פעולה זו.`)) {
      setIsSubmittingGroupAction(true);
      let successCount = 0;
      let errorCount = 0;

      try {
        const batchSize = 5;
        const delay = 1000;
        
        for (let i = 0; i < participantsToDelete.length; i += batchSize) {
          const batch = participantsToDelete.slice(i, i + batchSize);
          const promises = batch.map(participant => {
            return Participant.delete(participant.id)
              .then(() => {
                successCount++;
                return Promise.resolve();
              })
              .catch(singleError => {
                errorCount++;
                console.error(`Error deleting participant ID: ${participant.id}`, singleError);
                return Promise.resolve();
              });
          });
          
          await Promise.all(promises);
          
          if (i + batchSize < participantsToDelete.length) {
            await new Promise(resolve => setTimeout(resolve, delay));
          }
        }

        if (errorCount > 0) {
          alert(`מחיקה הושלמה חלקית. ${successCount} משתתפים נמחקו, ${errorCount} נכשלו.`);
        } else {
          alert(`מחיקה הושלמה בהצלחה. כל ${successCount} המשתתפים נמחקו.`);
        }

        setSelectedParticipants(new Set());
        await loadParticipantsAndPrizes();
      } catch (error) {
        console.error("Error in selected participants delete process:", error);
        alert("שגיאה כללית במחיקת המשתתפים שנבחרו.");
      } finally {
        setIsSubmittingGroupAction(false);
      }
    }
  };

  const toggleParticipantSelection = (participantId) => {
    const newSelection = new Set(selectedParticipants);
    if (newSelection.has(participantId)) {
      newSelection.delete(participantId);
    } else {
      newSelection.add(participantId);
    }
    setSelectedParticipants(newSelection);
  };

  const selectAllVisibleParticipants = () => {
    const currentFilteredParticipants = getFilteredParticipants(allParticipantsData, selectedGroup, searchTerm, advancedFilters, drawnPrizes);
    const newSelection = new Set(selectedParticipants);
    currentFilteredParticipants.forEach(p => newSelection.add(p.id));
    setSelectedParticipants(newSelection);
  };

  const clearAllSelections = () => {
    setSelectedParticipants(new Set());
  };

  const handleOpenGroupEditModal = (groupName) => {
    if (groupName && groupName !== "הכל") {
      if (groupName === "ללא קבוצה") {
        setShowNoGroupAssignModal(true);
      } else {
        setGroupToEdit(groupName);
        setShowGroupEditModal(true);
      }
    }
  };

  const handleAssignNoGroupParticipants = async (targetGroupName) => {
    setIsSubmittingGroupAction(true);
    const participantsWithoutGroup = allParticipantsData.filter(p => !p.group_name);
    
    let successCount = 0;
    let errorCount = 0;

    try {
      const batchSize = 5;
      const delay = 1000;
      
      for (let i = 0; i < participantsWithoutGroup.length; i += batchSize) {
        const batch = participantsWithoutGroup.slice(i, i + batchSize);
        const promises = batch.map(participant => {
          return Participant.update(participant.id, {
            ...participant,
            group_name: targetGroupName
          })
          .then(() => {
            successCount++;
            return Promise.resolve();
          })
          .catch(singleError => {
            errorCount++;
            console.error(`Error updating participant ID: ${participant.id}`, singleError);
            return Promise.resolve();
          });
        });
        
        await Promise.all(promises);
        
        if (i + batchSize < participantsWithoutGroup.length) {
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
      
      if (errorCount > 0) {
        alert(`שיוך לקבוצה הושלם חלקית. ${successCount} משתתפים הועברו, ${errorCount} נכשלו.`);
      } else {
        alert(`שיוך לקבוצה הושלם בהצלחה. כל ${successCount} המשתתפים שויכו.`);
      }

      setShowNoGroupAssignModal(false);
      await loadParticipantsAndPrizes();
      setSelectedGroup(targetGroupName);
      
    } catch (error) {
      console.error("Generic error during assignment process:", error);
      alert("שגיאה כללית בתהליך שיוך המשתתפים לקבוצה. אנא נסה שוב.");
    } finally {
      setIsSubmittingGroupAction(false);
    }
  };
  
  const getExistingGroupNames = () => {
    return [...new Set(allParticipantsData.map(p => p.group_name).filter(Boolean))];
  };

  const handleSaveGroupNameChange = async (oldGroupName, newGroupName) => {
    setIsSubmittingGroupAction(true);
    const participantsToUpdate = allParticipantsData.filter(p => p.group_name === oldGroupName);
    let successCount = 0;
    let errorCount = 0;
    
    try {
      const batchSize = 5;
      const delay = 1000;
      
      for (let i = 0; i < participantsToUpdate.length; i += batchSize) {
        const batch = participantsToUpdate.slice(i, i + batchSize);
        const promises = batch.map(participant => {
          return Participant.update(participant.id, {
            ...participant,
            group_name: newGroupName
          })
          .then(() => {
            successCount++;
            return Promise.resolve();
          })
          .catch(singleError => {
            errorCount++;
            console.error(`Error updating participant ID: ${participant.id} from group ${oldGroupName}`, singleError);
            return Promise.resolve();
          });
        });
        
        await Promise.all(promises);
        
        if (i + batchSize < participantsToUpdate.length) {
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
      
      if (errorCount > 0) {
        alert(`שינוי שם קבוצה הושלם חלקית. ${successCount} משתתפים עודכנו, ${errorCount} נכשלו.`);
      } else {
        alert(`שינוי שם קבוצה הושלם בהצלחה. ${successCount} משתתפים עודכנו.`);
      }
      
      setShowGroupEditModal(false);
      setGroupToEdit(null);
      await loadParticipantsAndPrizes();
      
      if (selectedGroup === oldGroupName) {
        setSelectedGroup(newGroupName);
      }
      
    } catch (error) {
      console.error("Generic error renaming group:", error);
      alert("שגיאה בעדכון שם הקבוצה. אנא נסה שוב.");
    } finally {
      setIsSubmittingGroupAction(false);
    }
  };

  const handleDeleteGroup = async (groupName) => {
    setIsSubmittingGroupAction(true);
    const participantsToUpdate = allParticipantsData.filter(p => p.group_name === groupName);
    let successCount = 0;
    let errorCount = 0;
    
    try {
      const batchSize = 5;
      const delay = 1000;
      
      for (let i = 0; i < participantsToUpdate.length; i += batchSize) {
        const batch = participantsToUpdate.slice(i, i + batchSize);
        const promises = batch.map(participant => {
          return Participant.update(participant.id, {
            ...participant,
            group_name: null
          })
          .then(() => {
            successCount++;
            return Promise.resolve();
          })
          .catch(singleError => {
            errorCount++;
            console.error(`Error unassigning participant ID: ${participant.id} from group ${groupName}`, singleError);
            return Promise.resolve();
          });
        });
        
        await Promise.all(promises);
        
        if (i + batchSize < participantsToUpdate.length) {
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
      
      if (errorCount > 0) {
        alert(`מחיקת קבוצה הושלמה חלקית. ${successCount} משתתפים הוסרו מהקבוצה, ${errorCount} נכשלו.`);
      } else {
        alert(`מחיקת קבוצה הושלמה בהצלחה. ${successCount} משתתפים הוסרו מהקבוצה.`);
      }

      setShowGroupEditModal(false);
      setGroupToEdit(null);
      await loadParticipantsAndPrizes();
      
      if (selectedGroup === groupName) {
        setSelectedGroup("ללא קבוצה");
      }

    } catch (error) {
      console.error("Generic error deleting group:", error);
      alert("שגיאה במחיקת הקבוצה. אנא נסה שוב.");
    } finally {
      setIsSubmittingGroupAction(false);
    }
  };

  const totalParticipantsCount = allParticipantsData.length;
  const activeParticipantsCount = allParticipantsData.filter(p => p.active).length;
  const groupTabs = getGroupTabs(allParticipantsData);
  const filteredParticipants = getFilteredParticipants(allParticipantsData, selectedGroup, searchTerm, advancedFilters, drawnPrizes);
  const noGroupParticipants = allParticipantsData.filter(p => !p.group_name);

  const getGroupsFromAdvancedFilter = () => {
    if (!advancedFilters.showGroupsDrawn && !advancedFilters.showGroupsNotDrawn) {
      return [];
    }

    const drawnGroupNames = new Set(drawnPrizes.map(prize => {
      const participant = allParticipantsData.find(p => p.id === prize.winner_id);
      return participant?.group_name;
    }).filter(Boolean));

    if (advancedFilters.showGroupsDrawn && !advancedFilters.showGroupsNotDrawn) {
      return Array.from(drawnGroupNames).sort();
    } else if (advancedFilters.showGroupsNotDrawn && !advancedFilters.showGroupsDrawn) {
      const allGroups = new Set(allParticipantsData.map(p => p.group_name).filter(Boolean));
      return Array.from(allGroups).filter(group => !drawnGroupNames.has(group)).sort();
    }
    return [];
  };

  const relevantGroups = getGroupsFromAdvancedFilter();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-card p-6 shadow-lg">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl flex items-center justify-center shadow-md">
              <Users className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-800 dark:text-white">ניהול משתתפים</h1>
              <p className="text-slate-600 dark:text-slate-400 text-sm">
                סה"כ {totalParticipantsCount} משתתפים • {activeParticipantsCount} פעילים
                {selectedParticipants.size > 0 && ` • ${selectedParticipants.size} נבחרו`}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {selectedParticipants.size > 0 && (
              <Button
                variant="destructive"
                onClick={deleteSelectedParticipants}
                disabled={isSubmittingGroupAction}
                size="sm"
              >
                {isSubmittingGroupAction ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}
                מחק נבחרים ({selectedParticipants.size})
              </Button>
            )}
             <Button
              variant="outline"
              onClick={() => setShowForm(true)}
              disabled={isSubmittingGroupAction}
              className="bg-blue-600 hover:bg-blue-700 text-white dark:bg-blue-500 dark:hover:bg-blue-600"
              size="sm"
            >
              <Plus className="w-4 h-4 mr-2" />
              הוסף משתתף
            </Button>
          </div>
        </div>
         <div className="mt-4 flex flex-col sm:flex-row gap-2">
            <Button
              variant="outline"
              onClick={() => setShowImport(true)}
              disabled={isSubmittingGroupAction}
              className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
              size="sm"
            >
              <Upload className="w-4 h-4 mr-2" />
              ייבוא מאקסל
            </Button>
            <Button
              variant="outline"
              onClick={() => setShowPasteImport(true)}
              disabled={isSubmittingGroupAction}
              className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
              size="sm"
            >
              <ClipboardPaste className="w-4 h-4 mr-2" />
              הדבק רשימה
            </Button>
            <Button
              variant="outline"
              onClick={exportParticipants}
              disabled={totalParticipantsCount === 0 || isSubmittingGroupAction}
              className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
              size="sm"
            >
              <Download className="w-4 h-4 mr-2" />
              ייצוא
            </Button>
            <Button
              variant="outline"
              onClick={resetParticipants}
              disabled={totalParticipantsCount === 0 || isLoading || isSubmittingGroupAction}
              className="text-red-600 border-red-300 hover:bg-red-50 dark:text-red-400 dark:border-red-500 dark:hover:bg-red-500/20"
              size="sm"
            >
              {(isSubmittingGroupAction || isLoading) ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RotateCcw className="w-4 h-4 mr-2" />}
              אפס רשימה
            </Button>
          </div>
      </div>

      {/* Group Tabs */}
      <div className="glass-card p-4 shadow-md">
        <div className="flex flex-wrap gap-2">
          {groupTabs.map((group, index) => (
            <div key={group.name} className="relative group">
              <motion.button
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.03 }}
                onClick={() => !isSubmittingGroupAction && setSelectedGroup(group.name)}
                disabled={isSubmittingGroupAction}
                className={`px-3 py-2 rounded-md font-medium text-sm transition-all duration-200 flex items-center gap-1.5 ${
                  selectedGroup === group.name
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-600'
                } ${isSubmittingGroupAction ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <span>{group.name}</span>
                <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                  selectedGroup === group.name
                    ? 'bg-white/20 text-white'
                    : 'bg-slate-300 dark:bg-slate-600 text-slate-600 dark:text-slate-200'
                }`}>
                  {group.count}
                </span>
              </motion.button>
              {group.name !== "הכל" && !isSubmittingGroupAction && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleOpenGroupEditModal(group.name)}
                  className="absolute -top-2 -left-2 w-5 h-5 rounded-full bg-slate-300 dark:bg-slate-600 hover:bg-slate-400 dark:hover:bg-slate-500 text-slate-600 dark:text-slate-200 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center shadow"
                  title={group.name === "ללא קבוצה" ? `שייך משתתפים לקבוצה` : `ערוך קבוצה "${group.name}"`}
                >
                  {group.name === "ללא קבוצה" ? <UserPlus className="w-3 h-3" /> : <Edit3 className="w-3 h-3" />}
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Bulk Actions for "No Group" */}
      {selectedGroup === "ללא קבוצה" && noGroupParticipants.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-4 shadow-md"
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-semibold text-slate-800 dark:text-white">פעולות על משתתפים ללא קבוצה</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">ניתן לשייך לקבוצה או למחוק את כל המשתתפים ללא קבוצה.</p>
            </div>
            <div className="flex gap-2 flex-shrink-0">
              <Button
                onClick={deleteAllNoGroupParticipants}
                disabled={isSubmittingGroupAction}
                variant="outline"
                size="sm"
                className="text-red-600 border-red-300 hover:bg-red-50 dark:text-red-400 dark:border-red-500 dark:hover:bg-red-500/20"
              >
                {isSubmittingGroupAction ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RotateCcw className="w-4 h-4 mr-2" />}
                מחק הכל ({noGroupParticipants.length})
              </Button>
              <Button
                onClick={() => setShowNoGroupAssignModal(true)}
                disabled={isSubmittingGroupAction}
                size="sm"
                className="bg-blue-600 hover:bg-blue-700 text-white dark:bg-blue-500 dark:hover:bg-blue-600"
              >
                {isSubmittingGroupAction ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <UserPlus className="w-4 h-4 mr-2" />}
                שייך לקבוצה
              </Button>
            </div>
          </div>
        </motion.div>
      )}

      {/* Multi-select controls */}
      {filteredParticipants.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-3 shadow-md"
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-sm text-slate-600 dark:text-slate-400">בחירה מרובה:</span>
              <Button
                variant="outline"
                size="sm" 
                onClick={selectAllVisibleParticipants}
                disabled={isSubmittingGroupAction}
                className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
              >
                בחר הכל ({filteredParticipants.length})
              </Button>
              {selectedParticipants.size > 0 && (
                <Button
                  variant="outline"
                  size="sm" 
                  onClick={clearAllSelections}
                  disabled={isSubmittingGroupAction}
                  className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
                >
                  בטל בחירה
                </Button>
              )}
            </div>
            {selectedParticipants.size > 0 && (
              <span className="text-sm font-medium text-blue-600 dark:text-blue-400">
                {selectedParticipants.size} משתתפים נבחרו
              </span>
            )}
          </div>
        </motion.div>
      )}

      {/* סינונים מתקדמים */}
      <div className="glass-card p-4 shadow-md">
        <div className="flex flex-col gap-4">
          <h3 className="text-lg font-semibold text-slate-800 dark:text-white flex items-center gap-2">
            <Filter className="w-5 h-5" />
            סינונים מתקדמים
          </h3>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={advancedFilters.showActiveOnly}
                onChange={(e) => setAdvancedFilters(prev => ({
                  ...prev,
                  showActiveOnly: e.target.checked,
                  showInactiveOnly: e.target.checked ? false : prev.showInactiveOnly
                }))}
                className="rounded text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm text-slate-700 dark:text-slate-300">משתתפים פעילים בלבד</span>
            </label>
            
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={advancedFilters.showInactiveOnly}
                onChange={(e) => setAdvancedFilters(prev => ({
                  ...prev,
                  showInactiveOnly: e.target.checked,
                  showActiveOnly: e.target.checked ? false : prev.showActiveOnly
                }))}
                className="rounded text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm text-slate-700 dark:text-slate-300">משתתפים לא פעילים בלבד</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={advancedFilters.showGroupsDrawn}
                onChange={(e) => setAdvancedFilters(prev => ({
                  ...prev,
                  showGroupsDrawn: e.target.checked,
                  showGroupsNotDrawn: e.target.checked ? false : prev.showGroupsNotDrawn
                }))}
                className="rounded text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm text-slate-700 dark:text-slate-300">קבוצות שכבר הוגרלו</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={advancedFilters.showGroupsNotDrawn}
                onChange={(e) => setAdvancedFilters(prev => ({
                  ...prev,
                  showGroupsNotDrawn: e.target.checked,
                  showGroupsDrawn: e.target.checked ? false : prev.showGroupsDrawn
                }))}
                className="rounded text-blue-600 focus:ring-blue-500"
              />
              <span className="text-sm text-slate-700 dark:text-slate-300">קבוצות שטרם הוגרלו</span>
            </label>
          </div>

          {/* כרטיסיות קבוצות רלוונטיות למסנן */}
          {relevantGroups.length > 0 && (
            <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 rounded-lg">
              <h4 className="text-sm font-semibold text-blue-800 dark:text-blue-300 mb-2 flex items-center gap-1">
                <Users className="w-4 h-4" />
                {advancedFilters.showGroupsDrawn ? "קבוצות שהוגרלו:" : "קבוצות שטרם הוגרלו:"}
              </h4>
              <div className="flex flex-wrap gap-2">
                {relevantGroups.map((groupName) => (
                  <button
                    key={groupName}
                    onClick={() => {
                      setSelectedGroup(groupName);
                      setAdvancedFilters(prev => ({
                        ...prev,
                        showGroupsDrawn: false,
                        showGroupsNotDrawn: false
                      }));
                    }}
                    className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all duration-200 ${
                      selectedGroup === groupName
                        ? 'bg-blue-600 text-white shadow-md'
                        : 'bg-white dark:bg-slate-700 text-blue-700 dark:text-blue-300 border border-blue-300 dark:border-blue-500 hover:bg-blue-100 dark:hover:bg-blue-500/20'
                    }`}
                  >
                    {groupName}
                    <span className="mr-1 text-xs opacity-75">
                      ({allParticipantsData.filter(p => p.group_name === groupName).length})
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Loading Overlay for group actions */}
      {(isSubmittingGroupAction || isLoading) && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-[100]">
          <div className="flex flex-col items-center bg-white dark:bg-slate-800 p-8 rounded-xl shadow-2xl">
            <Loader2 className="w-10 h-10 text-blue-600 dark:text-blue-400 animate-spin mb-4" />
            <p className="text-lg font-medium text-slate-700 dark:text-slate-200">מעדכן נתונים, אנא המתן...</p>
          </div>
        </div>
      )}

      {/* Search */}
      <div className="glass-card p-4 shadow-md">
        <div className="relative">
          <Input
            placeholder={`חיפוש ב${selectedGroup === "הכל" ? "כל המשתתפים" : `קבוצת "${selectedGroup}"`}...`}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pr-10 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200 dark:placeholder-slate-400"
            disabled={isSubmittingGroupAction}
          />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 dark:text-slate-500 w-5 h-5" />
        </div>
      </div>

      {/* Modals */}
      <AnimatePresence>
        {showImport && (
          <ParticipantImport
            onClose={() => setShowImport(false)}
            onComplete={async () => {
              setShowImport(false);
              await loadParticipantsAndPrizes();
            }}
          />
        )}
        {showPasteImport && (
          <ParticipantPasteImport
            onClose={() => setShowPasteImport(false)}
            onComplete={async () => {
              setShowPasteImport(false);
              await loadParticipantsAndPrizes();
            }}
          />
        )}
        {showForm && (
          <ParticipantForm
            participant={editingParticipant}
            onSave={handleSaveParticipant}
            onClose={() => {
              setShowForm(false);
              setEditingParticipant(null);
            }}
          />
        )}
        {showGroupEditModal && groupToEdit && (
          <GroupEditModal
            groupName={groupToEdit}
            onClose={() => {
              setShowGroupEditModal(false);
              setGroupToEdit(null);
            }}
            onSaveName={handleSaveGroupNameChange}
            onDeleteGroup={handleDeleteGroup}
            isSubmitting={isSubmittingGroupAction}
          />
        )}
        {showNoGroupAssignModal && (
          <NoGroupAssignModal
            participants={noGroupParticipants}
            existingGroups={getExistingGroupNames()}
            onClose={() => setShowNoGroupAssignModal(false)}
            onAssignToGroup={handleAssignNoGroupParticipants}
            isSubmitting={isSubmittingGroupAction}
          />
        )}
      </AnimatePresence>
      
      {/* Remove Background Import Progress Bar */}


      {/* Participants List */}
      <ParticipantList
        participants={filteredParticipants}
        isLoading={isLoading && !isSubmittingGroupAction}
        onEdit={handleEditParticipant}
        onDelete={handleDeleteParticipant}
        currentGroup={selectedGroup}
        selectedParticipants={selectedParticipants}
        onToggleSelection={toggleParticipantSelection}
        multiSelectEnabled={true}
      />
    </div>
  );
}
