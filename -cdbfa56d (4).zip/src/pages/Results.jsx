
import React, { useState, useEffect } from "react";
import { Prize } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { CardContent } from "@/components/ui/card"; // Assuming CardContent is from shadcn/ui
import { Trophy, Download, RotateCcw, Star, Calendar, RefreshCw, Loader2, User, Tag } from "lucide-react"; // Added Loader2, User, Tag
import { motion } from "framer-motion";
import { format } from "date-fns";
import { he } from "date-fns/locale";

const formatIsraeliTime = (dateString, formatStr) => {
  const date = new Date(dateString);
  const israelTime = new Date(date.getTime() + (3 * 60 * 60 * 1000));
  return format(israelTime, formatStr, { locale: he });
};

export default function ResultsPage() {
  const [results, setResults] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadResults();
  }, []);

  const loadResults = async () => {
    setIsLoading(true);
    try {
      const drawnPrizes = await Prize.filter({ drawn: true }, "-created_date"); // Changed from -updated_date to -created_date
      setResults(drawnPrizes);
    } catch(error) {
      console.error("Error loading results:", error);
      // In a real application, you might set an error state here to display to the user.
    } finally {
      setIsLoading(false);
    }
  };

  const exportResults = () => {
    if (results.length === 0) {
        alert("אין תוצאות לייצוא.");
        return;
    }
    
    // Sort by created_date in ascending order for export
    const sortedResults = [...results].sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    
    const csvData = sortedResults.map(result => ({
      'פרס': result.name,
      'זוכה': result.winner_name,
      'ערך': result.value || '',
      'תאריך הגרלה': formatIsraeliTime(result.updated_date, "dd/MM/yyyy HH:mm")
    }));

    const headers = Object.keys(csvData[0]);
    const csvContent = [
      headers.join(','),
      ...csvData.map(row => headers.map(header => `"${String(row[header]).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `תוצאות_הגרלה_${formatIsraeliTime(new Date(), "dd-MM-yyyy")}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url); // Clean up the URL object
  };

  const resetAllResults = async () => {
    if (confirm('האם אתה בטוח שברצונך להחזיר את *כל* הפרסים שהוגרלו למצב "זמין להגרלה"? פעולה זו תמחק את שמות הזוכים מכל הפרסים.')) {
      setIsLoading(true);
      try {
        for (const result of results) {
          await Prize.update(result.id, {
            winner_id: null,
            winner_name: null,
            drawn: false
          });
        }
      } catch (error) {
        console.error("Error resetting all results:", error);
        alert("שגיאה באיפוס כל התוצאות.");
      } finally {
        await loadResults(); // Reloads and sets isLoading to false
      }
    }
  };

  const returnSinglePrize = async (prizeId, prizeName) => {
    if (confirm(`האם אתה בטוח שברצונך להחזיר את הפרס "${prizeName}" למאגר הפרסים הזמינים? פרטי הזוכה הנוכחי ימחקו.`)) {
      setIsLoading(true);
      try {
        await Prize.update(prizeId, {
          winner_id: null,
          winner_name: null,
          drawn: false
        });
      } catch (error) {
        console.error(`Error returning prize ${prizeId}:`, error);
        alert(`שגיאה בהחזרת הפרס "${prizeName}".`);
      } finally {
        await loadResults(); // Reloads and sets isLoading to false
      }
    }
  };

  const totalValue = results.reduce((sum, r) => sum + (Number(r.value) || 0), 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div
        className="glass-card p-6 shadow-lg"
      >
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-green-700 rounded-xl flex items-center justify-center shadow-md">
              <Star className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-800 dark:text-white">תוצאות הגרלות</h1>
              <p className="text-slate-600 dark:text-slate-400 text-sm">
                {results.length} זכיות • ₪{totalValue.toLocaleString()} סה"כ ערך הפרסים שהוגרלו
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              onClick={resetAllResults}
              disabled={results.length === 0 || isLoading}
              size="sm"
              className="text-red-600 border-red-300 hover:bg-red-50 dark:text-red-400 dark:border-red-500 dark:hover:bg-red-500/20"
            >
              {isLoading && results.length > 0 ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RotateCcw className="w-4 h-4 mr-2" />}
              אפס הכל
            </Button>
            <Button
              onClick={exportResults}
              disabled={results.length === 0 || isLoading}
              size="sm"
              className="bg-blue-600 hover:bg-blue-700 text-white dark:bg-blue-500 dark:hover:bg-blue-600"
            >
              <Download className="w-4 h-4 mr-2" />
              ייצא תוצאות
            </Button>
          </div>
        </div>
      </div>

      {/* Results */}
      {isLoading && results.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <Loader2 className="w-10 h-10 text-blue-500 dark:text-blue-400 mx-auto animate-spin" />
          <p className="mt-3 text-slate-600 dark:text-slate-400">טוען תוצאות...</p>
        </div>
      ) : results.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass-card p-8 sm:p-12 text-center"
        >
          <Trophy className="w-12 h-12 sm:w-16 sm:h-16 text-slate-400 dark:text-slate-500 mx-auto mb-4" />
          <h3 className="text-xl sm:text-2xl font-semibold text-slate-700 dark:text-slate-200 mb-2">אין תוצאות עדיין</h3>
          <p className="text-slate-500 dark:text-slate-400 text-sm sm:text-base">עדיין לא בוצעו הגרלות. עבור לדף "הגרלה" כדי להתחיל!</p>
        </motion.div>
      ) : (
        <div className="grid gap-4">
          {results.map((result, index) => (
            <motion.div
              key={result.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05, duration: 0.3 }}
              className="glass-card p-0 hover:shadow-xl dark:hover:shadow-slate-700/50 transition-shadow duration-300 overflow-hidden"
            >
              <CardContent className="p-4 sm:p-5">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3 sm:gap-4 flex-1 min-w-0">
                    <div className="w-10 h-10 sm:w-11 sm:h-11 bg-gradient-to-br from-amber-400 to-amber-600 dark:from-amber-500 dark:to-amber-700 rounded-lg flex items-center justify-center text-white font-bold text-lg shrink-0 shadow-sm">
                      {index + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-base sm:text-lg font-semibold text-slate-800 dark:text-slate-100 truncate" title={result.name}>{result.name}</h3>
                      <div className="flex items-center gap-x-3 gap-y-1 mt-0.5 flex-wrap text-xs sm:text-sm">
                        <span className="text-blue-600 dark:text-blue-400 font-semibold flex items-center gap-1">
                          <User className="w-3.5 h-3.5"/> {result.winner_name}
                        </span>
                        {(result.value || result.value === 0) && ( // Ensure 0 value is displayed
                          <span className="text-green-600 dark:text-green-400 font-medium flex items-center gap-1">
                            <Tag className="w-3.5 h-3.5"/> ₪{Number(result.value).toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row items-end sm:items-center gap-2 sm:gap-3 mt-2 sm:mt-0 w-full sm:w-auto">
                    <div className="text-right text-xs text-slate-500 dark:text-slate-400">
                      <div className="flex items-center gap-1 justify-end">
                        <Calendar className="w-3 h-3" />
                        {formatIsraeliTime(result.updated_date, "dd/MM/yyyy")}
                      </div>
                      <div className="mt-0.5 text-right sm:text-left"> {/* Ensure time is on new line and aligned */}
                        {formatIsraeliTime(result.updated_date, "HH:mm:ss")}
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="xs"
                      onClick={() => returnSinglePrize(result.id, result.name)}
                      disabled={isLoading}
                      className="text-orange-600 border-orange-300 hover:bg-orange-50 dark:text-orange-400 dark:border-orange-500 dark:hover:bg-orange-500/20 w-full sm:w-auto"
                    >
                      {isLoading ? <Loader2 className="w-3 h-3 mr-1.5 animate-spin" /> : <RefreshCw className="w-3 h-3 mr-1.5" />}
                      החזר להגרלה
                    </Button>
                  </div>
                </div>
                {result.description && (
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-2 pr-[calc(2.5rem+1rem)] sm:pr-[calc(2.75rem+1rem)]"> {/* Indent description */}
                    {result.description}
                  </p>
                )}
              </CardContent>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
