
import React, { useState, useEffect, useMemo, useCallback } from "react";
import { Prize } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Gift, Upload, Plus, Search, Download, ClipboardPaste, RotateCcw, Loader2, Filter, Trash2, CheckSquare, Square } from "lucide-react";
import { AnimatePresence } from "framer-motion";

import PrizeImport from "../components/prizes/PrizeImport";
import PrizeList from "../components/prizes/PrizeList";
import PrizeForm from "../components/prizes/PrizeForm";
import PrizePasteImport from "../components/prizes/PrizePasteImport";

// This custom hook encapsulates the state and logic related to prizes management.
// It simulates the refactoring mentioned in the outline, making PrizesPage cleaner.
function usePrizesLogic() {
  const [allPrizesData, setAllPrizesData] = useState([]);
  const [drawnParticipants, setDrawnParticipants] = useState([]); // Placeholder for future use, not currently used in this file
  const [showImport, setShowImport] = useState(false);
  const [showPasteImport, setShowPasteImport] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editingPrize, setEditingPrize] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(true); // For initial/full data loading
  const [isSubmitting, setIsSubmitting] = useState(false); // For individual save/delete operations
  const [selectedPrizes, setSelectedPrizes] = useState([]); // For multi-selection

  // New state for primary status filtering (e.g., All, Available, Drawn)
  const [selectedPrizeStatus, setSelectedPrizeStatus] = useState("הכל");

  // Removed new state for advanced filters as per requirements

  // Function to load prizes and participants
  const loadPrizesAndParticipants = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await Prize.list("-created_date"); // Assuming this loads all prizes
      setAllPrizesData(data);
      // setDrawnParticipants(await Participant.list({ drawn: true })); // Example of loading drawn participants
      setDrawnParticipants([]); // Placeholder, as Participant entity is not in scope of this file
    } catch (error) {
      console.error("Failed to load prizes or participants:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Effect to load data on component mount
  useEffect(() => {
    loadPrizesAndParticipants();
  }, [loadPrizesAndParticipants]);

  // Handler for saving a prize (create or update)
  const handleSavePrize = useCallback(async (prizeData) => {
    setIsSubmitting(true);
    try {
      if (editingPrize) {
        await Prize.update(editingPrize.id, prizeData);
      } else {
        await Prize.create(prizeData);
      }
      setShowForm(false);
      setEditingPrize(null);
      await loadPrizesAndParticipants(); // Reload data after save
    } catch (error) {
      console.error("Error saving prize:", error);
    } finally {
      setIsSubmitting(false);
    }
  }, [editingPrize, loadPrizesAndParticipants]);

  // Handler for editing an existing prize
  const handleEditPrize = useCallback((prize) => {
    setEditingPrize(prize);
    setShowForm(true);
  }, []);

  // Handler for deleting a prize
  const handleDeletePrize = useCallback(async (prizeId) => {
    setIsSubmitting(true);
    try {
      await Prize.delete(prizeId);
      await loadPrizesAndParticipants(); // Reload data after delete
    } catch (error) {
      console.error("Error deleting prize:", error);
    } finally {
      setIsSubmitting(false);
    }
  }, [loadPrizesAndParticipants]);

  // Handler for when import operations complete
  const handleImportComplete = useCallback(async () => {
    setShowImport(false);
    setShowPasteImport(false);
    await loadPrizesAndParticipants(); // Reload data after import
  }, [loadPrizesAndParticipants]);

  // Handler for exporting prizes to CSV
  const exportPrizes = useCallback(() => {
    const csvData = allPrizesData.map(p => ({
      'שם הפרס': p.name,
      'תיאור': p.description || '',
      'ערך': p.value || '',
      'זוכה': p.winner_name || '',
      'הוגרל': p.drawn ? 'כן' : 'לא'
    }));

    if (csvData.length === 0) {
        alert("אין נתונים לייצוא.");
        return;
    }
    const headers = Object.keys(csvData[0]);
    const csvContent = [
      headers.join(','),
      ...csvData.map(row => headers.map(header => {
        let value = row[header];
        if (typeof value === 'string') {
          // Escape double quotes by doubling them, then enclose the whole field in double quotes
          value = value.replace(/"/g, '""');
        }
        return `"${value}"`;
      }).join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'prizes.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, [allPrizesData]);

  // Handler for resetting (deleting all) prizes
  const resetPrizes = useCallback(async () => {
    if (window.confirm("האם אתה בטוח שברצונך למחוק את כל הפרסים? לא ניתן לשחזר פעולה זו.")) {
      setIsSubmitting(true);
      try {
        const prizesToDelete = [...allPrizesData];
        const batchSize = 10;
        const delayBetweenBatches = 1000;

        for (let i = 0; i < prizesToDelete.length; i += batchSize) {
            const batch = prizesToDelete.slice(i, i + batchSize);
            const promises = batch.map(p => Prize.delete(p.id).catch(e => console.error(e)));
            await Promise.all(promises);

            if (i + batchSize < prizesToDelete.length) {
                await new Promise(resolve => setTimeout(resolve, delayBetweenBatches));
            }
        }
      } catch (error) {
        console.error("Error resetting prizes:", error);
        alert("שגיאה באיפוס רשימת הפרסים.");
      } finally {
        await loadPrizesAndParticipants(); // Reload data after reset
        setIsSubmitting(false);
      }
    }
  }, [allPrizesData, loadPrizesAndParticipants]);

  // Multi-selection functions
  const togglePrizeSelection = useCallback((prizeId) => {
    setSelectedPrizes(prev =>
      prev.includes(prizeId) ? prev.filter(id => id !== prizeId) : [...prev, prizeId]
    );
  }, []);

  const selectAllVisiblePrizes = useCallback((currentFilteredPrizes) => {
    // If all visible prizes are already selected, deselect all. Otherwise, select all visible.
    if (currentFilteredPrizes.length > 0 && currentFilteredPrizes.every(p => selectedPrizes.includes(p.id))) {
        setSelectedPrizes([]);
    } else {
        setSelectedPrizes(currentFilteredPrizes.map(p => p.id));
    }
  }, [selectedPrizes]);

  const clearAllSelections = useCallback(() => {
    setSelectedPrizes([]);
  }, []);

  const deleteSelectedPrizes = useCallback(async () => {
    if (selectedPrizes.length === 0) {
      alert("אנא בחר פרסים למחיקה.");
      return;
    }
    if (window.confirm(`האם אתה בטוח שברצונך למחוק ${selectedPrizes.length} פרסים?`)) {
      setIsSubmitting(true);
      try {
        const batchSize = 10;
        const delayBetweenBatches = 1000;

        for (let i = 0; i < selectedPrizes.length; i += batchSize) {
            const batch = selectedPrizes.slice(i, i + batchSize);
            const promises = batch.map(id => Prize.delete(id).catch(e => console.error(e)));
            await Promise.all(promises);

            if (i + batchSize < selectedPrizes.length) {
                await new Promise(resolve => setTimeout(resolve, delayBetweenBatches));
            }
        }
        setSelectedPrizes([]); // Clear selection after deletion
      } catch (error) {
        console.error("Error deleting selected prizes:", error);
        alert("שגיאה במחיקת הפרסים הנבחרים.");
      } finally {
        await loadPrizesAndParticipants(); // Reload data after deletion
        setIsSubmitting(false);
      }
    }
  }, [selectedPrizes, loadPrizesAndParticipants]);

  return {
    allPrizesData,
    drawnParticipants,
    showImport, setShowImport,
    showPasteImport, setShowPasteImport,
    showForm, setShowForm,
    editingPrize, setEditingPrize,
    searchTerm, setSearchTerm,
    isLoading, // Initial/full load indicator
    selectedPrizeStatus, setSelectedPrizeStatus,
    isSubmitting, // Action-specific loading indicator
    selectedPrizes, setSelectedPrizes,
    // advancedFilters, setAdvancedFilters, // Removed
    loadPrizesAndParticipants, handleSavePrize, handleEditPrize, handleDeletePrize,
    handleImportComplete, exportPrizes, resetPrizes,
    togglePrizeSelection, selectAllVisiblePrizes, clearAllSelections, deleteSelectedPrizes
  };
}


export default function PrizesPage() {
  const {
    allPrizesData,
    // drawnParticipants is returned by hook but not used directly in PrizesPage rendering logic
    showImport, setShowImport,
    showPasteImport, setShowPasteImport,
    showForm, setShowForm,
    editingPrize, setEditingPrize,
    searchTerm, setSearchTerm,
    isLoading, // From hook, indicates overall data loading
    selectedPrizeStatus, setSelectedPrizeStatus,
    isSubmitting, // From hook, indicates individual action submission
    selectedPrizes, togglePrizeSelection, selectAllVisiblePrizes,
    clearAllSelections, deleteSelectedPrizes,
    // advancedFilters, setAdvancedFilters, // הסרתי את זה
    // loadPrizesAndParticipants, // Not directly called by render logic
    handleSavePrize, handleEditPrize, handleDeletePrize,
    handleImportComplete, exportPrizes, resetPrizes,
  } = usePrizesLogic();

  // Calculate counts for header and status tabs
  const totalPrizesCount = allPrizesData.length;
  const availablePrizesCount = allPrizesData.filter(p => !p.drawn).length;
  const drawnPrizesCount = totalPrizesCount - availablePrizesCount;
  
  const statusTabs = [
    { name: "הכל", count: totalPrizesCount },
    { name: "זמינים", count: availablePrizesCount },
    { name: "הוגרלו", count: drawnPrizesCount },
  ];

  // Memoized filtering logic - רק סינון בסיסי
  const filteredPrizes = useMemo(() => {
    let filtered = allPrizesData;

    // Apply primary status filter (All, Available, Drawn)
    if (selectedPrizeStatus !== "הכל") {
      filtered = filtered.filter(p => (selectedPrizeStatus === "זמינים" ? !p.drawn : p.drawn));
    }

    // Apply basic search term filter
    if (searchTerm) {
      filtered = filtered.filter(p =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (p.description && p.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (p.winner_name && p.winner_name.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    // Removed advanced filter application

    return filtered;
  }, [allPrizesData, selectedPrizeStatus, searchTerm]); // הסרתי את advancedFilters

  // Determine if all visible prizes are currently selected for the "select all" checkbox
  const areAllVisiblePrizesSelected = useMemo(() => {
    return filteredPrizes.length > 0 && filteredPrizes.every(p => selectedPrizes.includes(p.id));
  }, [filteredPrizes, selectedPrizes]);


  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div
        className="glass-card p-6 shadow-lg"
      >
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-amber-500 to-amber-700 rounded-xl flex items-center justify-center shadow-md">
              <Gift className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-800 dark:text-white">ניהול פרסים</h1>
              <p className="text-slate-600 dark:text-slate-400 text-sm">
                סה"כ {totalPrizesCount} פרסים • {drawnPrizesCount} הוגרלו • ₪{allPrizesData.reduce((sum, p) => sum + (Number(p.value) || 0), 0).toLocaleString()} סה"כ ערך
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
             <Button
              onClick={() => setShowForm(true)}
              className="bg-amber-600 hover:bg-amber-700 text-white dark:bg-amber-500 dark:hover:bg-amber-600"
              size="sm"
            >
              <Plus className="w-4 h-4 mr-2" />
              הוסף פרס
            </Button>
          </div>
        </div>
         <div className="mt-4 flex flex-col sm:flex-row gap-2">
            <Button
              variant="outline"
              onClick={() => setShowImport(true)}
              className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
              size="sm"
            >
              <Upload className="w-4 h-4 mr-2" />
              ייבוא מאקסל
            </Button>
            <Button
              variant="outline"
              onClick={() => setShowPasteImport(true)}
              className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
              size="sm"
            >
              <ClipboardPaste className="w-4 h-4 mr-2" />
              הדבק רשימה
            </Button>
            <Button
              variant="outline"
              onClick={exportPrizes}
              disabled={allPrizesData.length === 0 || isLoading || isSubmitting}
              className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
              size="sm"
            >
              <Download className="w-4 h-4 mr-2" />
              ייצוא
            </Button>
             <Button
              variant="outline"
              onClick={resetPrizes}
              disabled={allPrizesData.length === 0 || isLoading || isSubmitting}
              className="text-red-600 border-red-300 hover:bg-red-50 dark:text-red-400 dark:border-red-500 dark:hover:bg-red-500/20"
              size="sm"
            >
              {isSubmitting && !isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <RotateCcw className="w-4 h-4 mr-2" />}
              אפס רשימה
            </Button>
          </div>
      </div>

      {/* Status Tabs Section */}
      <div className="glass-card p-4 shadow-md">
        <div className="flex gap-2 flex-wrap">
          {statusTabs.map((tab) => (
            <Button
              key={tab.name}
              variant={selectedPrizeStatus === tab.name ? "default" : "outline"}
              onClick={() => setSelectedPrizeStatus(tab.name)}
              className={selectedPrizeStatus === tab.name ? "bg-blue-600 hover:bg-blue-700 text-white dark:bg-blue-500 dark:hover:bg-blue-600" : "dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"}
              size="sm"
            >
              {tab.name} ({tab.count})
            </Button>
          ))}
        </div>
      </div>

      {/* Multi-select controls section */}
      {selectedPrizes.length > 0 && (
        <div className="glass-card p-4 shadow-md flex items-center gap-4">
          <p className="text-sm text-slate-700 dark:text-slate-300">
            {selectedPrizes.length} פרסים נבחרו
          </p>
          <Button
            variant="ghost"
            onClick={clearAllSelections}
            className="text-blue-600 hover:bg-blue-50 dark:text-blue-400 dark:hover:bg-blue-900/20"
            size="sm"
            disabled={isSubmitting}
          >
            בטל בחירה
          </Button>
          <Button
            variant="destructive"
            onClick={deleteSelectedPrizes}
            className="bg-red-600 hover:bg-red-700 text-white dark:bg-red-500 dark:hover:bg-red-600"
            size="sm"
            disabled={isSubmitting}
          >
            {isSubmitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Trash2 className="w-4 h-4 mr-2" />}
            מחק נבחרים
          </Button>
        </div>
      )}

      {/* Search Input Section */}
      <div className="glass-card p-4 shadow-md">
        <div className="relative">
          <Input
            placeholder="חיפוש פרסים (שם, תיאור, זוכה)..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pr-10 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200 dark:placeholder-slate-400"
          />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 dark:text-slate-500 w-5 h-5" />
        </div>
      </div>

      {/* הסרתי את הסינונים המתקדמים */}

      {/* Loading Overlay for full page load */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-white/70 dark:bg-slate-800/70 z-50 rounded-lg">
          <Loader2 className="h-10 w-10 text-amber-500 animate-spin" />
        </div>
      )}

      {/* Modals for Prize Import, Paste Import, and Form */}
      <AnimatePresence>
        {showImport && (
          <PrizeImport
            onClose={() => setShowImport(false)}
            onComplete={handleImportComplete}
          />
        )}
        {showPasteImport && (
          <PrizePasteImport
            onClose={() => setShowPasteImport(false)}
            onComplete={handleImportComplete}
          />
        )}
        {showForm && (
          <PrizeForm
            prize={editingPrize}
            onSave={handleSavePrize}
            onClose={() => {
              setShowForm(false);
              setEditingPrize(null); // Clear editing prize when form closes
            }}
          />
        )}
      </AnimatePresence>

      {/* Prizes List Component */}
      <PrizeList
        prizes={filteredPrizes}
        isLoading={isLoading} // Pass overall loading state to the list
        onEdit={handleEditPrize}
        onDelete={handleDeletePrize}
        isSubmitting={isSubmitting} // Pass action-specific loading for individual prize operations
        selectedPrizes={selectedPrizes} // Pass current selected prize IDs
        togglePrizeSelection={togglePrizeSelection} // Pass function to toggle selection of an individual prize
        areAllVisiblePrizesSelected={areAllVisiblePrizesSelected} // Pass state for "select all" checkbox
        selectAllVisiblePrizes={() => selectAllVisiblePrizes(filteredPrizes)} // Pass function to select/deselect all visible
      />
    </div>
  );
}
