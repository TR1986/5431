
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Users, 
  Gift, 
  Sparkles, 
  Star,
  ChevronLeft,
  Menu
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const navigationItems = [
  {
    title: "משתתפים",
    url: createPageUrl("Participants"),
    icon: Users,
    color: "text-blue-500",
    bgColor: "bg-blue-100",
    hoverBgColor: "hover:bg-blue-200/70",
    activeGradient: "from-blue-500 to-blue-700"
  },
  {
    title: "פרסים",
    url: createPageUrl("Prizes"),
    icon: Gift,
    color: "text-amber-500",
    bgColor: "bg-amber-100",
    hoverBgColor: "hover:bg-amber-200/70",
    activeGradient: "from-amber-500 to-amber-700"
  },
  {
    title: "הגרלה",
    url: createPageUrl("Draw"),
    icon: Sparkles,
    color: "text-purple-500",
    bgColor: "bg-purple-100",
    hoverBgColor: "hover:bg-purple-200/70",
    activeGradient: "from-purple-500 to-purple-700"
  },
  {
    title: "תוצאות",
    url: createPageUrl("Results"),
    icon: Star,
    color: "text-green-500",
    bgColor: "bg-green-100",
    hoverBgColor: "hover:bg-green-200/70",
    activeGradient: "from-green-500 to-green-700"
  },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const pageTitle = navigationItems.find(item => location.pathname === item.url)?.title || currentPageName || "מערכת הגרלות";

  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-br from-slate-100 via-gray-100 to-stone-100 dark:from-slate-900 dark:via-gray-900 dark:to-stone-900 text-slate-800 dark:text-slate-200 transition-colors duration-300">
      <style>
        {`
          @import url('https://fonts.googleapis.com/css2?family=Assistant:wght@300;400;600;700&display=swap');
          * {
            font-family: 'Assistant', sans-serif;
          }
          
          :root {
            --radius: 0.75rem; /* Slightly larger radius */
            --primary-accent: #3B82F6; /* A nice blue */
            --secondary-accent: #F59E0B; /* The gold */
          }

          .gradient-accent {
            background: linear-gradient(135deg, var(--primary-accent) 0%, var(--secondary-accent) 100%);
          }
          
          .glass-card {
            background: rgba(255, 255, 255, 0.85); /* Brighter white */
            backdrop-filter: blur(12px) saturate(180%); /* Softer blur, more saturation */
            border: 1px solid rgba(209, 213, 219, 0.4); /* More visible border */
            border-radius: var(--radius);
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.15); /* More pronounced shadow */
          }

          .dark .glass-card {
            background: rgba(30, 41, 59, 0.85); /* Darker background for dark mode */
            border: 1px solid rgba(55, 65, 81, 0.4);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.25);
          }
          
          .sparkle-effect {
            animation: sparkle-effect 2.5s ease-in-out infinite;
          }
          
          @keyframes sparkle-effect {
            0%, 100% { transform: scale(1) rotate(0deg); opacity: 0.9; }
            50% { transform: scale(1.15) rotate(15deg); opacity: 1; }
          }

          /* Custom scrollbar for a cleaner look */
          ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
          }
          ::-webkit-scrollbar-track {
            background: rgba(0,0,0,0.05);
            border-radius: 10px;
          }
          ::-webkit-scrollbar-thumb {
            background: rgba(0,0,0,0.2);
            border-radius: 10px;
          }
          ::-webkit-scrollbar-thumb:hover {
            background: rgba(0,0,0,0.3);
          }
          .dark ::-webkit-scrollbar-track {
            background: rgba(255,255,255,0.05);
          }
          .dark ::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,0.2);
          }
          .dark ::-webkit-scrollbar-thumb:hover {
            background: rgba(255,255,255,0.3);
          }
        `}
      </style>

      {/* Main container with sidebar and content area */}
      <div className="flex h-screen">
        {/* Sidebar - Desktop */}
        <aside className="hidden md:flex flex-col w-64 bg-white dark:bg-slate-800 shadow-lg transition-colors duration-300">
          <div className="px-6 py-5 border-b border-slate-200 dark:border-slate-700">
            <Link to={createPageUrl("Participants")} className="flex items-center gap-3">
              <div className="w-10 h-10 gradient-accent rounded-lg flex items-center justify-center shadow-md">
                <Sparkles className="w-5 h-5 text-white sparkle-effect" />
              </div>
              <h1 className="text-xl font-bold text-slate-800 dark:text-white">גורלון</h1>
            </Link>
          </div>
          <nav className="flex-grow p-4 space-y-2">
            {navigationItems.map((item) => (
              <Link
                key={item.title}
                to={item.url}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ease-in-out group ${
                  location.pathname === item.url
                    ? `bg-gradient-to-r ${item.activeGradient} text-white shadow-lg scale-105`
                    : `${item.color} ${item.bgColor} dark:bg-slate-700 dark:text-slate-300 ${item.hoverBgColor} dark:hover:bg-slate-600 hover:text-slate-800 dark:hover:text-white`
                }`}
              >
                <item.icon className="w-5 h-5 transition-transform duration-200 group-hover:scale-110" />
                <span className="font-semibold">{item.title}</span>
              </Link>
            ))}
          </nav>
          <div className="p-4 border-t border-slate-200 dark:border-slate-700 text-center">
            <p className="text-xs text-slate-500 dark:text-slate-400">&copy; {new Date().getFullYear()} גורלון מבית Base44</p>
          </div>
        </aside>

        {/* Main content area */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Top bar - Mobile */}
          <header className="md:hidden bg-white dark:bg-slate-800 shadow-md p-4 flex items-center justify-between sticky top-0 z-40">
            <Link to={createPageUrl("Participants")} className="flex items-center gap-2">
              <div className="w-8 h-8 gradient-accent rounded-md flex items-center justify-center shadow-sm">
                <Sparkles className="w-4 h-4 text-white sparkle-effect" />
              </div>
              <h1 className="text-lg font-bold text-slate-800 dark:text-white">גורלון</h1>
            </Link>
            <button onClick={() => setMobileMenuOpen(true)} className="p-2 text-slate-600 dark:text-slate-300">
              <Menu className="w-6 h-6" />
            </button>
          </header>
          
          {/* Page Header (visible on desktop, part of main content scroll) */}
           <div className="hidden md:block bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm border-b border-slate-200 dark:border-slate-700 px-6 py-4 sticky top-0 z-30">
            <h2 className="text-2xl font-semibold text-slate-700 dark:text-slate-200">{pageTitle}</h2>
          </div>


          {/* Page Content */}
          <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={location.pathname}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                {children}
              </motion.div>
            </AnimatePresence>
          </main>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="md:hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
            onClick={() => setMobileMenuOpen(false)}
          >
            <motion.aside 
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="fixed top-0 right-0 bottom-0 w-64 bg-white dark:bg-slate-800 shadow-xl flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="px-6 py-5 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
                <Link to={createPageUrl("Participants")} className="flex items-center gap-3">
                  <div className="w-10 h-10 gradient-accent rounded-lg flex items-center justify-center shadow-md">
                    <Sparkles className="w-5 h-5 text-white sparkle-effect" />
                  </div>
                  <h1 className="text-xl font-bold text-slate-800 dark:text-white">גורלון</h1>
                </Link>
                <button onClick={() => setMobileMenuOpen(false)} className="p-2 text-slate-500 dark:text-slate-400">
                    <X className="w-5 h-5" />
                </button>
              </div>
              <nav className="flex-grow p-4 space-y-2">
                {navigationItems.map((item) => (
                  <Link
                    key={item.title}
                    to={item.url}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ease-in-out group ${
                      location.pathname === item.url
                        ? `bg-gradient-to-r ${item.activeGradient} text-white shadow-md`
                        : `${item.color} ${item.bgColor} dark:bg-slate-700 dark:text-slate-300 ${item.hoverBgColor} dark:hover:bg-slate-600 hover:text-slate-800 dark:hover:text-white`
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                    <span className="font-semibold">{item.title}</span>
                  </Link>
                ))}
              </nav>
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
