
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Trophy, Users } from "lucide-react";

export default function DrawWheel({ 
  participants,
  isDrawing, 
  winner, 
  selectedPrize, 
  drawIntensity = 0,
  displayNames = ["...", "...", "...", "...", "...", "...", "...", "..."], // New prop - array of 8 names
  drawDuration = 15000 // New prop: total duration of the draw in ms, default to 15000ms (15 seconds)
}) {

  return (
    <Card className={`glass-card shadow-xl relative overflow-hidden min-h-[400px] sm:min-h-[450px] flex flex-col justify-center items-center transition-all duration-300 ${
      isDrawing ? 'ring-4 ring-amber-400 dark:ring-amber-500 ring-opacity-75 scale-[1.01]' : ''
    }`}>
      
      {/* Background particles when drawing */}
      {isDrawing && !winner && Array.from({ length: 15 }).map((_, i) => (
        <motion.div
          key={`particle-${i}`}
          className="absolute rounded-full opacity-60"
          style={{
            width: `${4 + Math.random() * 8}px`,
            height: `${4 + Math.random() * 8}px`,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            background: ['#3B82F6', '#F59E0B', '#10B981', '#EF4444', '#8B5CF6'][Math.floor(Math.random() * 5)],
            zIndex: 3
          }}
          initial={{ scale: 0, opacity: 0 }}
          animate={{ 
            scale: [0, 1.5, 0.8, 0], 
            opacity: [0, 1, 0.8, 0],
            x: (Math.random() - 0.5) * 100,
            y: (Math.random() - 0.5) * 100,
          }}
          transition={{ 
            duration: 1.5 + Math.random() * 2,
            repeat: Infinity,
            delay: Math.random() * 2
          }}
        />
      ))}

      {/* Background scrolling names - more visible and prominent */}
      {isDrawing && participants && participants.length > 0 && Array.from({ length: 20 }).map((_, i) => (
        <motion.div
          key={`bg-name-${i}`}
          className="absolute text-lg sm:text-xl font-bold opacity-60 pointer-events-none select-none"
          style={{
            left: `${Math.random() * 90 + 5}%`,
            top: `${Math.random() * 90 + 5}%`,
            color: ['#3B82F6', '#F59E0B', '#10B981', '#EF4444', '#8B5CF6'][Math.floor(Math.random() * 5)],
            zIndex: 1
          }}
          initial={{ opacity: 0, scale: 0.3 }}
          animate={{
            opacity: [0, 0.6, 0],
            scale: [0.3, 1, 0.5],
            rotate: [-15, 15, -8],
            x: [(Math.random() - 0.5) * 150, (Math.random() - 0.5) * 150],
            y: [(Math.random() - 0.5) * 80, (Math.random() - 0.5) * 80],
          }}
          transition={{
            duration: 1.5 + Math.random() * 2,
            repeat: Infinity,
            delay: Math.random() * 1.5,
          }}
        >
          {participants[Math.floor(Math.random() * participants.length)]?.name}
        </motion.div>
      ))}

      <CardContent className="p-6 sm:p-8 relative z-10 w-full flex flex-col items-center text-center">
        {/* Prize Display */}
        <motion.div 
          className="mb-6 sm:mb-8"
          animate={{ scale: isDrawing ? 1 + drawIntensity * 0.05 : 1 }}
        >
          <motion.div
            animate={{ 
              scale: isDrawing ? 1 + (drawIntensity * 0.1) : 1,
              rotate: isDrawing ? drawIntensity * 10 : 0
            }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
            className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-amber-400 to-amber-600 dark:from-amber-500 dark:to-amber-700 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg"
          >
            <Trophy className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
          </motion.div>
          <h2 
            className="text-xl sm:text-2xl lg:text-3xl font-bold text-slate-800 dark:text-white truncate max-w-xs sm:max-w-sm md:max-w-md"
            title={selectedPrize?.name || "בחר פרס"}
          >
            {selectedPrize?.name || "בחר פרס להגרלה"}
          </h2>
          {(selectedPrize?.value || selectedPrize?.value === 0) && (
            <p className="text-base sm:text-lg text-green-600 dark:text-green-400 font-semibold">
              ₪{Number(selectedPrize.value).toLocaleString()}
            </p>
          )}
        </motion.div>

        {/* Main content area for names or winner */}
        <div className="relative min-h-[100px] sm:min-h-[120px] w-full flex items-center justify-center z-20">
          <AnimatePresence mode="wait">
            {winner ? (
              <motion.div
                key="winner-display"
                initial={{ scale: 0.5, opacity: 0, rotate: -30 }}
                animate={{ scale: 1, opacity: 1, rotate: 0 }}
                exit={{ scale: 0.8, opacity: 0 }}
                transition={{type: "spring", stiffness: 250, damping: 20, duration: 0.5}}
                className="text-center"
              >
                {Array.from({ length: 30 }).map((_, i) => (
                  <motion.div
                    key={`confetti-${i}`}
                    className="absolute w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full pointer-events-none"
                    style={{
                      backgroundColor: ['#FFD700', '#FF6B6B', '#4ECDC4', '#3B82F6', '#F59E0B'][i % 5],
                      top: '50%', left: '50%', zIndex: 30,
                    }}
                    initial={{ scale: 0, x: 0, y: 0 }}
                    animate={{
                      scale: [0, 1 + Math.random(), 0],
                      x: (Math.random() - 0.5) * (Math.random() * 300 + 150),
                      y: (Math.random() - 0.5) * (Math.random() * 200 + 100),
                      rotate: Math.random() * 720,
                    }}
                    transition={{ duration: 1.5 + Math.random() * 1, ease: "circOut", delay: 0.1 + Math.random() * 0.3 }}
                  />
                ))}
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: [0, 1.2, 1]}}
                  transition={{ delay: 0.2, duration: 0.5, ease: "backOut" }}
                  className="w-24 h-24 sm:w-28 sm:h-28 bg-gradient-to-br from-green-400 to-teal-500 dark:from-green-500 dark:to-teal-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-2xl"
                >
                  <Sparkles className="w-12 h-12 sm:w-14 sm:h-14 text-white sparkle-effect" />
                </motion.div>
                <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-slate-800 dark:text-white mb-1">מזל טוב!</h3>
                <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-blue-600 dark:text-blue-400 truncate max-w-xs sm:max-w-sm md:max-w-md" title={displayNames[0]}>
                  {displayNames[0]} 
                </p>
                <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 mt-1">
                  זכית ב{selectedPrize?.name}!
                </p>
              </motion.div>
            ) : isDrawing ? (
              <motion.div 
                key="drawing-names"
                className="text-center w-full"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <div className="grid grid-cols-4 gap-1 sm:gap-2 max-w-full">
                  {displayNames.map((name, index) => (
                    <div 
                      key={index}
                      className="text-sm sm:text-base lg:text-lg font-bold text-blue-700 dark:text-blue-400 p-1.5 sm:p-2 rounded-md bg-white/50 dark:bg-slate-700/50 shadow-inner min-h-[40px] sm:min-h-[50px] flex items-center justify-center truncate"
                      style={{
                        textShadow: `0 0 ${8 + drawIntensity * 12}px rgba(59, 130, 246, 0.4)`
                      }}
                    >
                      {name}
                    </div>
                  ))}
                </div>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
                  {drawIntensity < 0.6 ? "מגריל..." : drawIntensity < 0.85 ? "כמעט שם..." : "רגע האמת..."}
                </p>
              </motion.div>
            ) : selectedPrize ? (
              <motion.div 
                key="ready-to-draw"
                className="text-center w-full"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
              >
                <div className="w-16 h-16 sm:w-20 sm:h-20 bg-slate-100 dark:bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4">
                  <Users className="w-8 h-8 sm:w-10 sm:h-10 text-slate-500 dark:text-slate-400" />
                </div>
                <h3 className="text-xl sm:text-2xl font-semibold text-slate-700 dark:text-slate-200 mb-3">מוכנים להגרלה?</h3>
                 <p className="text-sm sm:text-base text-slate-500 dark:text-slate-400 mb-4">
                    ישנם משתתפים שממתינים במתח.
                 </p>
              </motion.div>
            ) : (
              <motion.div 
                key="placeholder"
                className="text-center"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                <Trophy className="w-12 h-12 sm:w-16 sm:h-16 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400 dark:text-slate-500">
                  { !selectedPrize ? "בחר פרס להתחלה." : "אין משתתפים זמינים."}
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </CardContent>

      {isDrawing && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute bottom-0 left-0 right-0 p-3 sm:p-4 z-20"
        >
          <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-3 sm:h-4 overflow-hidden shadow-inner">
            <motion.div
              className="bg-gradient-to-r from-amber-400 to-red-500 h-full rounded-full"
              initial={{ width: "0%" }}
              animate={{ width: `${drawIntensity * 100}%` }}
              transition={{ duration: 0.1, ease: "linear" }}
            />
          </div>
          <p className="text-xs sm:text-sm font-semibold text-center text-red-600 dark:text-red-400 mt-1.5">
            {Math.ceil((1 - drawIntensity) * (drawDuration / 1000))} שניות נותרו...
          </p>
        </motion.div>
      )}
    </Card>
  );
}
