import React, { useState } from "react";
import { UploadFile } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { X, Save, Settings, Image, Upload, Trash2, Loader2, AlertTriangle } from "lucide-react";
import { motion } from "framer-motion";

export default function DrawSettingsModal({ drawTitle, setDrawTitle, logoUrl, setLogoUrl, onClose }) {
  const [currentTitle, setCurrentTitle] = useState(drawTitle);
  const [currentLogoUrl, setCurrentLogoUrl] = useState(logoUrl);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState(null);

  const handleLogoUpload = async (event) => {
    const file = event.target.files[0];
    if (file) {
      setIsUploading(true);
      setUploadError(null);
      try {
        const { file_url } = await UploadFile({ file });
        setCurrentLogoUrl(file_url);
      } catch (error) {
        console.error("Error uploading logo:", error);
        setUploadError("שגיאה בהעלאת הלוגו. אנא נסה שוב.");
      } finally {
        setIsUploading(false);
      }
    }
  };

  const handleRemoveLogo = () => {
    setCurrentLogoUrl("");
  };

  const handleSave = () => {
    setDrawTitle(currentTitle);
    setLogoUrl(currentLogoUrl);
    onClose();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-[60]" // Increased z-index
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="w-full max-w-md"
        onClick={(e) => e.stopPropagation()}
      >
        <Card className="bg-white dark:bg-slate-800 shadow-2xl border dark:border-slate-700 rounded-xl">
          <CardHeader className="flex flex-row items-center justify-between pb-4 border-b dark:border-slate-700">
            <CardTitle className="text-xl font-semibold text-slate-800 dark:text-white flex items-center gap-2">
              <Settings className="w-5 h-5 text-purple-600 dark:text-purple-400" />
              הגדרות הגרלה
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200">
              <X className="w-5 h-5" />
            </Button>
          </CardHeader>
          <CardContent className="p-6 space-y-5">
            <div>
              <Label htmlFor="draw-title-input" className="text-sm font-medium text-slate-700 dark:text-slate-300">
                שם ההגרלה
              </Label>
              <Input
                id="draw-title-input"
                value={currentTitle}
                onChange={(e) => setCurrentTitle(e.target.value)}
                placeholder="הכנס שם להגרלה"
                className="mt-1.5 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200 focus:ring-purple-500 dark:focus:ring-purple-400"
              />
            </div>

            <div>
              <Label htmlFor="logo-url-input" className="text-sm font-medium text-slate-700 dark:text-slate-300">
                לוגו (קישור לתמונה או העלאה)
              </Label>
              <div className="flex items-center gap-2 mt-1.5">
                <Input
                  id="logo-url-input"
                  value={currentLogoUrl}
                  onChange={(e) => setCurrentLogoUrl(e.target.value)}
                  placeholder="הדבק קישור לתמונה או השאר ריק"
                  className="flex-grow dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200 focus:ring-purple-500 dark:focus:ring-purple-400"
                  disabled={isUploading}
                />
                <Button
                    variant="outline"
                    size="icon"
                    asChild
                    className="shrink-0 dark:border-slate-600 dark:hover:bg-slate-700"
                    disabled={isUploading}
                  >
                  <Label htmlFor="logo-upload-input">
                    {isUploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                  </Label>
                </Button>
                <Input id="logo-upload-input" type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" disabled={isUploading} />
              </div>
              {uploadError && (
                <p className="text-xs text-red-500 dark:text-red-400 mt-1 flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5"/> {uploadError}
                </p>
              )}
            </div>

            {currentLogoUrl && (
              <div className="space-y-2">
                <Label className="text-xs text-slate-500 dark:text-slate-400">תצוגה מקדימה של הלוגו:</Label>
                <div className="relative group w-24 h-24 border dark:border-slate-600 rounded-md flex items-center justify-center bg-slate-50 dark:bg-slate-700/50 overflow-hidden">
                  <img 
                    src={currentLogoUrl} 
                    alt="תצוגה מקדימה" 
                    className="max-w-full max-h-full object-contain"
                    onError={(e) => {
                      e.target.style.display = 'none'; // Hide broken image
                      const parent = e.target.parentElement;
                      if (parent && !parent.querySelector('.broken-image-placeholder')) { // Add placeholder only once
                        const placeholder = document.createElement('div');
                        placeholder.className = 'broken-image-placeholder flex flex-col items-center justify-center text-xs text-red-500 dark:text-red-400 text-center p-1';
                        placeholder.innerHTML = '<Image className="w-6 h-6 mb-0.5" /> קישור לא תקין';
                        parent.appendChild(placeholder);
                      }
                    }}
                  />
                  <Button
                    variant="destructive"
                    size="icon"
                    onClick={handleRemoveLogo}
                    className="absolute top-1 right-1 w-6 h-6 opacity-0 group-hover:opacity-100 transition-opacity bg-red-500/80 hover:bg-red-600/90"
                    disabled={isUploading}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter className="border-t dark:border-slate-700 p-4 flex gap-3">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
            >
              ביטול
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-purple-600 hover:bg-purple-700 dark:bg-purple-500 dark:hover:bg-purple-600 text-white"
            >
              <Save className="w-4 h-4 mr-2" />
              שמור הגדרות
            </Button>
          </CardFooter>
        </Card>
      </motion.div>
    </motion.div>
  );
}