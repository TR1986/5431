import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Play, RotateCcw, Trophy, Users, Gift, Volume2, VolumeX, Settings, Shuffle, PlusCircle, Loader2, AlertTriangle } from "lucide-react"; 
import { motion } from "framer-motion";

export default function DrawSetup({
  prizesForSelection,
  selectedPrize,
  onSelectPrize,
  participantsCount,
  isDrawing,
  onStartDraw,
  onStartAdditionalDraw,
  onNewDraw,
  winner,
  drawDuration,
  setDrawDuration,
  isMuted,
  toggleMute,
  onShuffleParticipants,
  selectedGroup,
  participantsAvailableForAdditionalDrawCount,
  audioReady
}) {
  const canStartInitialDraw = selectedPrize && !selectedPrize.drawn && participantsCount > 0 && !isDrawing && !winner;
  const canStartAdditionalDraw = selectedPrize && winner && participantsAvailableForAdditionalDrawCount > 0 && !isDrawing;

  const handleDurationChange = (e) => {
    const value = parseInt(e.target.value, 10);
    if (value >= 1 && value <= 60) { // Min 1 sec, Max 60 sec
      setDrawDuration(value * 1000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Prize Selection */}
      <Card className="glass-card shadow-md">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-lg font-semibold text-slate-700 dark:text-slate-200">
            <Gift className="w-5 h-5 text-amber-500 dark:text-amber-400" />
            בחירת פרס
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Select
            value={selectedPrize?.id || ""}
            onValueChange={(value) => {
              const prize = prizesForSelection.find(p => p.id === value);
              onSelectPrize(prize);
            }}
            disabled={isDrawing || !!winner} 
          >
            <SelectTrigger className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200">
              <SelectValue placeholder="בחר פרס להגרלה ראשונית" />
            </SelectTrigger>
            <SelectContent className="dark:bg-slate-800 dark:border-slate-700">
              {prizesForSelection.length > 0 ? prizesForSelection.map((prize) => (
                <SelectItem key={prize.id} value={prize.id} className="dark:focus:bg-slate-700">
                  <div className="flex items-center justify-between w-full">
                    <span>{prize.name}</span>
                    {(prize.value || prize.value === 0) && (
                      <span className="text-xs text-green-600 dark:text-green-400 font-medium mr-2">
                        ₪{Number(prize.value).toLocaleString()}
                      </span>
                    )}
                  </div>
                </SelectItem>
              )) : <div className="p-3 text-center text-sm text-slate-500 dark:text-slate-400">אין פרסים שטרם הוגרלו.</div>}
            </SelectContent>
          </Select>
          
          {selectedPrize && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              transition={{ duration: 0.3 }}
              className="mt-3 p-3 bg-blue-50 dark:bg-slate-700/50 rounded-md border border-blue-200 dark:border-slate-600"
            >
              <h4 className="font-semibold text-blue-800 dark:text-blue-300">{selectedPrize.name}</h4>
              {selectedPrize.description && (
                <p className="text-xs text-blue-700 dark:text-blue-400 mt-0.5">{selectedPrize.description}</p>
              )}
              {(selectedPrize.value || selectedPrize.value === 0) && (
                <p className="text-sm font-semibold text-green-600 dark:text-green-400 mt-1">
                  ₪{Number(selectedPrize.value).toLocaleString()}
                </p>
              )}
               {selectedPrize.drawn && !winner && ( // This prize has been drawn (but no current winner is being displayed for it)
                <p className="text-xs text-orange-600 dark:text-orange-400 mt-1">פרס זה כבר הוגרל. ניתן לבצע הגרלת זוכה נוסף או לבחור פרס אחר.</p>
              )}
            </motion.div>
          )}
        </CardContent>
      </Card>

      {/* Draw Controls */}
      <Card className="glass-card shadow-md">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center justify-between text-lg font-semibold text-slate-700 dark:text-slate-200">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-500 dark:text-blue-400" />
              בקרת הגרלה
            </div>
            <Button
              variant="outline"
              size="xs" // Smaller button
              onClick={onShuffleParticipants}
              disabled={isDrawing || !!winner || participantsCount === 0}
              className="dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
            >
              <Shuffle className="w-3 h-3 mr-1" />
              ערבב
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="text-center py-2 px-3 bg-slate-100 dark:bg-slate-700 rounded-md">
            <p className="text-2xl font-bold text-slate-800 dark:text-white">{participantsCount}</p>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              משתתפים זמינים {selectedGroup && selectedGroup !== "all" ? `בקבוצת "${selectedGroup}"` : ""}
            </p>
          </div>

          {winner ? (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-2.5"
            >
              <div className="p-3 bg-gradient-to-r from-green-400 to-teal-500 dark:from-green-600 dark:to-teal-700 rounded-md text-center text-white shadow-lg">
                <Trophy className="w-6 h-6 mx-auto mb-1" />
                <h4 className="font-semibold text-sm">הזוכה האחרון:</h4>
                <p className="text-lg font-bold">{winner.name}</p>
                {winner.group_name && <p className="text-xs opacity-80">(מקבוצת: {winner.group_name})</p>}
                <p className="text-xs opacity-80 mt-0.5">בפרס: {selectedPrize?.name}</p>
              </div>
              <Button
                onClick={onStartAdditionalDraw}
                disabled={!canStartAdditionalDraw || isDrawing}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white dark:bg-blue-500 dark:hover:bg-blue-600"
              >
                <PlusCircle className="w-4 h-4 mr-2" />
                הגרל זוכה נוסף ({participantsAvailableForAdditionalDrawCount} זמינים)
              </Button>
              <Button
                onClick={onNewDraw}
                className="w-full" 
                variant="outline"
                disabled={isDrawing}
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                הגרלה חדשה
              </Button>
            </motion.div>
          ) : (
            <Button
              onClick={onStartDraw}
              disabled={!canStartInitialDraw || isDrawing}
              className="w-full bg-gradient-to-r from-amber-500 to-red-600 hover:from-amber-600 hover:to-red-700 text-white text-base py-2.5 shadow-lg hover:shadow-xl transition-all duration-200"
            >
              {isDrawing ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  מגריל...
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 mr-2" />
                  התחל הגרלה!
                </>
              )}
            </Button>
          )}

          {(!selectedPrize || (participantsCount === 0 && !winner && !selectedPrize?.drawn)) && !isDrawing && (
            <div className="text-center text-xs text-slate-500 dark:text-slate-400 mt-1 p-2 bg-slate-100 dark:bg-slate-700/60 rounded-md flex items-center gap-2 justify-center">
                <AlertTriangle className="w-4 h-4 text-orange-500"/>
                <span>
                {!selectedPrize && "בחר פרס להגרלה."}
                {selectedPrize && participantsCount === 0 && !winner && !selectedPrize?.drawn && (selectedGroup === "all" ? "אין משתתפים זמינים." : `אין משתתפים זמינים בקבוצת "${selectedGroup}".`)}
                </span>
            </div>
          )}
           {selectedPrize && selectedPrize.drawn && !winner && !isDrawing && (
             <div className="text-center text-xs text-blue-600 dark:text-blue-400 mt-1 p-2 bg-blue-50 dark:bg-blue-500/20 rounded-md">
                פרס זה כבר הוגרל. בחר זוכה נוסף או פרס אחר.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Settings Card */}
      <Card className="glass-card shadow-md">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-lg font-semibold text-slate-700 dark:text-slate-200">
            <Settings className="w-5 h-5 text-slate-500 dark:text-slate-400" />
            הגדרות
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <Label htmlFor="drawDuration" className="text-sm text-slate-600 dark:text-slate-300">משך אנימציה (שניות)</Label>
            <Input
              id="drawDuration"
              type="number"
              value={drawDuration / 1000}
              onChange={handleDurationChange}
              min="1"
              max="60"
              className="mt-1 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200"
              disabled={isDrawing || !!winner}
            />
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">מומלץ: 15 שניות למתח אופטימלי</p>
          </div>
          <Button
            variant="outline"
            onClick={toggleMute}
            className="w-full flex items-center justify-center gap-2 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
            disabled={isDrawing && !winner} 
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            {isMuted ? "הפעל צליל" : "השתק צליל"}
            {!audioReady && !isMuted && <span className="text-xs text-orange-500">(טוען...)</span>}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}