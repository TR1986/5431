import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, Clock, Gift as GiftIcon, User } from "lucide-react"; // Renamed Gift to GiftIcon
import { format } from "date-fns";
import { he } from "date-fns/locale";
import { motion } from "framer-motion";

const formatIsraeliTime = (dateString, formatStr) => {
  try {
    const date = new Date(dateString);
    // Assuming server time is UTC, adjust to Israel time (UTC+3 or UTC+2 depending on DST)
    // For simplicity, using a fixed offset. A proper solution would use a timezone library.
    // const israelTime = new Date(date.getTime() + (3 * 60 * 60 * 1000)); 
    // date-fns handles localization well if the input date is correctly interpreted.
    return format(date, formatStr, { locale: he });
  } catch (e) {
    console.error("Error formatting date:", e);
    return String(dateString); // fallback
  }
};

export default function DrawResults({ drawHistory }) {
  if (!drawHistory || drawHistory.length === 0) {
    return (
      <Card className="glass-card shadow-md">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg font-semibold text-slate-700 dark:text-slate-200">
            <Trophy className="w-5 h-5 text-slate-500 dark:text-slate-400" />
            הגרלות אחרונות
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-500 dark:text-slate-400 text-center py-4">
            עדיין לא בוצעו הגרלות בסבב זה.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card shadow-md">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg font-semibold text-slate-700 dark:text-slate-200">
          <Trophy className="w-5 h-5 text-green-500 dark:text-green-400" />
          הגרלות אחרונות
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1"> {/* Added pr-1 for scrollbar space */}
          {drawHistory.map((draw, index) => ( // No need to slice or reverse if already prepending
            <motion.div
              key={draw.timestamp.toISOString() + '-' + draw.prize.id + '-' + index} // More robust key
              initial={{ opacity: 0, x: -15 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05, duration: 0.2 }}
              className="p-2.5 bg-slate-50 dark:bg-slate-700/70 rounded-md border border-slate-200 dark:border-slate-600/50"
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 text-sm font-semibold text-blue-600 dark:text-blue-400 truncate">
                    <User className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate" title={draw.participant.name}>{draw.participant.name}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 mt-0.5 truncate">
                    <GiftIcon className="w-3.5 h-3.5 shrink-0" />
                     <span className="truncate" title={draw.prize.name}>{draw.prize.name}</span>
                  </div>
                </div>
                <div className="text-right text-xs text-slate-500 dark:text-slate-400 shrink-0">
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{formatIsraeliTime(draw.timestamp, "HH:mm:ss")}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}