// Standardize modal styling
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { X, UserPlus, Loader2, Users } from 'lucide-react'; // Added Users icon
import { motion } from 'framer-motion';

export default function NoGroupAssignModal({ participants, existingGroups, onClose, onAssignToGroup, isSubmitting }) {
  const [selectedGroup, setSelectedGroup] = useState("");
  const [newGroupName, setNewGroupName] = useState("");
  const [assignmentMode, setAssignmentMode] = useState(existingGroups.length > 0 ? "existing" : "new"); // Default to "new" if no existing groups

  const handleAssign = () => {
    const targetGroup = assignmentMode === "existing" ? selectedGroup : newGroupName.trim();
    if (targetGroup) {
      onAssignToGroup(targetGroup);
    }
  };

  const canAssign = assignmentMode === "existing" ? !!selectedGroup : !!newGroupName.trim();

  const ModalWrapper = motion.div;

  return (
    <ModalWrapper
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="w-full max-w-md"
        onClick={(e) => e.stopPropagation()}
      >
        <Card className="bg-white dark:bg-slate-800 shadow-2xl border dark:border-slate-700 rounded-xl">
          <CardHeader className="flex flex-row items-center justify-between pb-4 border-b dark:border-slate-700">
            <CardTitle className="text-xl font-semibold text-slate-800 dark:text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-green-600 dark:text-green-400"/>
                שיוך משתתפים לקבוצה
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose} disabled={isSubmitting} className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200">
              <X className="w-5 h-5" />
            </Button>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className="p-3 bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 rounded-lg">
              <p className="text-sm text-blue-700 dark:text-blue-300">
                <strong>{participants.length}</strong> משתתפים ללא קבוצה ישוייכו לקבוצה שתבחר.
              </p>
            </div>

            <div className="space-y-3">
              <Label className="text-sm font-medium text-slate-700 dark:text-slate-300">בחר קבוצה קיימת או צור חדשה:</Label>
              
              <div className="flex gap-2">
                <Button
                  variant={assignmentMode === "existing" ? "default" : "outline"}
                  onClick={() => setAssignmentMode("existing")}
                  disabled={isSubmitting || existingGroups.length === 0}
                  className={`flex-1 ${assignmentMode === "existing" ? "bg-blue-600 text-white dark:bg-blue-500" : "dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"}`}
                >
                  קבוצה קיימת
                </Button>
                <Button
                  variant={assignmentMode === "new" ? "default" : "outline"}
                  onClick={() => setAssignmentMode("new")}
                  disabled={isSubmitting}
                  className={`flex-1 ${assignmentMode === "new" ? "bg-blue-600 text-white dark:bg-blue-500" : "dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"}`}
                >
                  קבוצה חדשה
                </Button>
              </div>

              {assignmentMode === "existing" ? (
                existingGroups.length > 0 ? (
                  <Select value={selectedGroup} onValueChange={setSelectedGroup} disabled={isSubmitting}>
                    <SelectTrigger className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200">
                      <SelectValue placeholder="בחר קבוצה קיימת" />
                    </SelectTrigger>
                    <SelectContent className="dark:bg-slate-800 dark:border-slate-700">
                      {existingGroups.map(group => (
                        <SelectItem key={group} value={group} className="dark:focus:bg-slate-700">{group}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <p className="text-xs text-slate-500 dark:text-slate-400 p-2 bg-slate-100 dark:bg-slate-700/50 rounded text-center">אין קבוצות קיימות. צור קבוצה חדשה.</p>
                )
              ) : (
                <Input
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  placeholder="הכנס שם לקבוצה החדשה"
                  disabled={isSubmitting}
                  className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200 focus:ring-blue-500 dark:focus:ring-blue-400"
                />
              )}
            </div>
          </CardContent>
          <CardFooter className="p-4 border-t dark:border-slate-700 flex gap-3">
              <Button
                variant="outline"
                onClick={onClose}
                disabled={isSubmitting}
                className="flex-1 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
              >
                ביטול
              </Button>
              <Button
                onClick={handleAssign}
                disabled={!canAssign || isSubmitting}
                className="flex-1 bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600 text-white"
              >
                {isSubmitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <UserPlus className="w-4 h-4 mr-2" />}
                שייך לקבוצה
              </Button>
          </CardFooter>
        </Card>
      </motion.div>
    </ModalWrapper>
  );
}