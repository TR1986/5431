// Standardize modal styling
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { X, Save, Trash2, AlertTriangle, Loader2, Edit3 } from 'lucide-react';
import { motion } from 'framer-motion';

export default function GroupEditModal({ groupName, onClose, onSaveName, onDeleteGroup, isSubmitting }) {
  const [newGroupName, setNewGroupName] = useState(groupName);

  useEffect(() => {
    setNewGroupName(groupName);
  }, [groupName]);

  const handleSave = () => {
    if (newGroupName.trim() && newGroupName.trim() !== groupName) {
      onSaveName(groupName, newGroupName.trim());
    }
  };

  const handleDelete = () => {
    if (window.confirm(`האם אתה בטוח שברצונך למחוק את הקבוצה "${groupName}"? כל המשתתפים בקבוצה זו ישוייכו ל"ללא קבוצה". לא ניתן לשחזר פעולה זו.`)) {
      onDeleteGroup(groupName);
    }
  };
  
  const ModalWrapper = motion.div;

  return (
    <ModalWrapper
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="w-full max-w-md"
        onClick={(e) => e.stopPropagation()}
      >
        <Card className="bg-white dark:bg-slate-800 shadow-2xl border dark:border-slate-700 rounded-xl">
          <CardHeader className="flex flex-row items-center justify-between pb-4 border-b dark:border-slate-700">
            <CardTitle className="text-xl font-semibold text-slate-800 dark:text-white flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-blue-600 dark:text-blue-400"/>
                עריכת קבוצה: {groupName}
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose} disabled={isSubmitting} className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200">
              <X className="w-5 h-5" />
            </Button>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div>
              <Label htmlFor="group_name_edit_modal" className="text-sm font-medium text-slate-700 dark:text-slate-300">שם קבוצה חדש</Label>
              <Input
                id="group_name_edit_modal"
                value={newGroupName}
                onChange={(e) => setNewGroupName(e.target.value)}
                placeholder="הכנס שם קבוצה"
                disabled={isSubmitting}
                className="mt-1 dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200 focus:ring-blue-500 dark:focus:ring-blue-400"
              />
              {newGroupName.trim() === "" && <p className="text-xs text-red-500 dark:text-red-400 mt-1">שם קבוצה לא יכול להיות ריק.</p>}
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-3 p-4 border-t dark:border-slate-700">
            <Button 
              onClick={handleSave} 
              disabled={!newGroupName.trim() || newGroupName.trim() === groupName || isSubmitting}
              className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white"
            >
              {isSubmitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
              שמור שינוי שם
            </Button>
            <div className="w-full border-t dark:border-slate-600 my-2"></div>
            <div className="p-3 bg-red-50 dark:bg-red-500/10 rounded-lg border border-red-200 dark:border-red-500/20 w-full">
                <div className="flex items-start gap-2">
                    <AlertTriangle className="w-5 h-5 text-red-600 dark:text-red-400 mt-0.5 shrink-0"/>
                    <div>
                        <h4 className="font-semibold text-red-700 dark:text-red-300">מחיקת קבוצה</h4>
                        <p className="text-xs text-red-600 dark:text-red-500">פעולה זו תסיר את השיוך הקבוצתי מכל המשתתפים בקבוצה "{groupName}". הם לא ימחקו, אלא יעברו ל"ללא קבוצה".</p>
                    </div>
                </div>
                 <Button 
                    variant="destructive" 
                    onClick={handleDelete} 
                    className="w-full mt-3"
                    disabled={isSubmitting}
                    >
                    {isSubmitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}
                    מחק את הקבוצה "{groupName}"
                </Button>
            </div>
          </CardFooter>
        </Card>
      </motion.div>
    </ModalWrapper>
  );
}