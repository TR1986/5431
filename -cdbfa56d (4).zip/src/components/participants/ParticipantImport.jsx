import React, { useState } from "react";
import { ExtractDataFromUploadedFile, UploadFile } from "@/api/integrations";
import { Participant } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Upload, X, CheckCircle, AlertTriangle, Users, Loader2, Zap, Play } from "lucide-react";
import { motion } from "framer-motion";

export default function ParticipantImport({ onClose, onComplete }) {
  const [file, setFile] = useState(null);
  const [groupName, setGroupName] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedData, setExtractedData] = useState(null);
  const [error, setError] = useState(null);

  const handleFileSelect = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setExtractedData(null);
      setError(null);
    }
  };

  const processFile = async () => {
    if (!file) return;

    setIsProcessing(true);
    setError(null);
    setExtractedData(null);

    try {
      const { file_url } = await UploadFile({ file: file });
      if (!file_url) {
        throw new Error("File upload failed, no URL returned.");
      }

      const extractionResult = await ExtractDataFromUploadedFile({
        file_url: file_url,
        json_schema: {
          type: "array",
          items: {
            type: "object",
            properties: {
              name: { type: "string" },
              email: { type: "string", format: "email", nullable: true },
              phone: { type: "string", nullable: true }
            },
            required: ["name"]
          }
        }
      });

      if (extractionResult.status === "success" && extractionResult.output && Array.isArray(extractionResult.output)) {
        const validParticipants = extractionResult.output.filter(p => p.name && typeof p.name === 'string' && p.name.trim() !== "");
        if (validParticipants.length > 0) {
          setExtractedData(validParticipants);
        } else {
          setError("לא נמצאו שמות משתתפים תקינים בקובץ.");
        }
      } else {
        console.error("Extraction failed:", extractionResult.details);
        setError(`שגיאה בעיבוד הקובץ: ${extractionResult.details || "פורמט לא נתמך או שגיאה פנימית."}`);
      }
    } catch (err) {
      console.error("Error processing file:", err);
      setError(`אירעה שגיאה בתהליך העיבוד: ${err.message}. נסה קובץ אחר או בדוק את הפורמט.`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleStart = async () => {
    if (!extractedData || extractedData.length === 0) {
      setError("אין נתונים תקינים לייבוא.");
      return;
    }
    
    setIsProcessing(true);
    const participantsToCreate = extractedData.map(p => ({
      name: p.name.trim(),
      email: p.email || "",
      phone: p.phone || "",
      active: true,
      group_name: groupName.trim() || null
    }));

    try {
      await Participant.bulkCreate(participantsToCreate);
      alert(`ייבוא מהיר הושלם! ${participantsToCreate.length} משתתפים נוספו בהצלחה.`);
      onComplete();
    } catch (err) {
      console.error("Bulk create failed:", err);
      setError("הייבוא המהיר נכשל. ייתכן שישנה מגבלה על כמות הנתונים או בעיית הרשאות. נסה לייבא קובץ קטן יותר (עד 100 שורות).");
    } finally {
      setIsProcessing(false);
    }
  };

  const ModalWrapper = motion.div;

  return (
    <ModalWrapper
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="w-full max-w-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <Card className="bg-white dark:bg-slate-800 shadow-2xl border dark:border-slate-700 rounded-xl">
          <CardHeader className="flex flex-row items-center justify-between pb-4 border-b dark:border-slate-700">
            <CardTitle className="text-xl font-semibold text-slate-800 dark:text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-500"/>
              ייבוא משתתפים (מהיר)
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200">
              <X className="w-5 h-5" />
            </Button>
          </CardHeader>
          <CardContent className="p-6 space-y-5">
            <div className="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-xl p-6 text-center hover:border-blue-500 dark:hover:border-blue-400 transition-colors">
              <Upload className="w-10 h-10 text-slate-400 dark:text-slate-500 mx-auto mb-3" />
              <Label htmlFor="participant-file-upload" className="text-base font-medium text-slate-700 dark:text-slate-200 cursor-pointer">
                בחר קובץ אקסל (xlsx) או CSV
              </Label>
              <Input
                id="participant-file-upload"
                type="file"
                accept=".xlsx,.csv"
                onChange={handleFileSelect}
                className="hidden"
              />
              {file ? (
                <p className="text-sm text-blue-600 dark:text-blue-400 mt-1">{file.name}</p>
              ) : (
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">הייבוא ישלח את כל הקובץ במכה אחת</p>
              )}
            </div>

            {!extractedData && file && (
                <Button onClick={processFile} disabled={isProcessing || !file} className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white">
                  {isProcessing ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : "עבד קובץ"}
                </Button>
            )}

            {extractedData && (
              <>
                <div className="p-3 bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20 rounded-lg text-green-700 dark:text-green-300 flex items-center gap-2 text-sm">
                  <CheckCircle className="w-5 h-5" />
                  נמצאו {extractedData.length.toLocaleString()} משתתפים תקינים בקובץ.
                </div>
                 <div className="space-y-1.5">
                  <Label htmlFor="import_group_name" className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center">
                    <Users className="w-4 h-4 ml-2 opacity-70" />
                    שייך לקבוצה (אופציונלי)
                  </Label>
                  <Input
                    id="import_group_name"
                    value={groupName}
                    onChange={(e) => setGroupName(e.target.value)}
                    placeholder="הכנס שם קבוצה"
                    className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200"
                  />
                </div>

                 <div className="max-h-32 overflow-y-auto border dark:border-slate-600 rounded-md p-2 space-y-1 bg-slate-50 dark:bg-slate-700/30 text-xs">
                  {extractedData.slice(0, 5).map((p, i) => (
                    <div key={i} className="bg-white/70 dark:bg-slate-700/50 p-1.5 rounded dark:text-slate-300 truncate">
                      {p.name} {p.email && `(${p.email})`} {p.phone && `[${p.phone}]`}
                    </div>
                  ))}
                  {extractedData.length > 5 && <p className="text-center text-xs text-slate-500 dark:text-slate-400 mt-1">ועוד {(extractedData.length - 5).toLocaleString()}...</p>}
                </div>
              </>
            )}

            {error && (
                <div className="flex items-center gap-2 p-2.5 mt-2 bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 rounded-lg text-sm text-red-700 dark:text-red-400">
                  <AlertTriangle className="w-4 h-4" />
                  <p>{error}</p>
                </div>
            )}
          </CardContent>
          {extractedData && (
            <CardFooter className="border-t dark:border-slate-700 p-4 flex gap-2">
                <Button
                    variant="outline"
                    onClick={() => { setExtractedData(null); setError(null); setFile(null); setGroupName(""); }}
                    className="flex-1 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
                  >
                    נקה
                  </Button>
                
                  <Button
                    onClick={handleStart}
                    disabled={isProcessing}
                    className="flex-1 bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600 text-white"
                  >
                    {isProcessing ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Play className="w-4 h-4 mr-2" />}
                    התחל ייבוא מהיר
                  </Button>
            </CardFooter>
          )}
        </Card>
      </motion.div>
    </ModalWrapper>
  );
}