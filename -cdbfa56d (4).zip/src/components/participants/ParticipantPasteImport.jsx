import React, { useState } from "react";
import { Participant } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { ClipboardPaste, X, CheckCircle, AlertTriangle, Users, Loader2, Zap, Play } from "lucide-react";
import { motion } from "framer-motion";

export default function ParticipantPasteImport({ onClose, onComplete }) {
  const [textList, setTextList] = useState("");
  const [groupName, setGroupName] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [parsedParticipants, setParsedParticipants] = useState(null);
  const [error, setError] = useState(null);

  const handleTextChange = (e) => {
    setTextList(e.target.value);
    setParsedParticipants(null);
    setError(null);
  };

  const processList = () => {
    if (!textList.trim()) {
      setError("תיבת הטקסט ריקה. אנא העתק והדבק רשימת משתתפים מאקסל או קובץ טקסט.");
      return;
    }
    
    setIsProcessing(true);
    setError(null);
    
    const lines = textList.split('\n').map(line => line.trim()).filter(line => line !== "");
    
    if (lines.length === 0) {
      setError("לא נמצאו נתונים תקינים ברשימה.");
      setParsedParticipants(null);
      setIsProcessing(false);
      return;
    }

    const participantsToImport = lines.map(line => {
      const columns = line.split(/\t|,/); 
      const name = columns[0] ? columns[0].trim() : "";
      const email = columns[1] ? columns[1].trim() : "";
      const phone = columns[2] ? columns[2].trim() : "";
      return { name, email, phone };
    }).filter(p => p.name);

    if (participantsToImport.length === 0) {
        setError("לא נמצאו שמות תקינים. ודא שהעמודה הראשונה מכילה את שמות המשתתפים.");
        setParsedParticipants(null);
        setIsProcessing(false);
        return;
    }

    setParsedParticipants(participantsToImport);
    setIsProcessing(false);
  };

  const handleStart = async () => {
    if (!parsedParticipants || parsedParticipants.length === 0) return;
    
    setIsProcessing(true);
    const participantsToCreate = parsedParticipants.map(p => ({
        name: p.name,
        email: p.email || '', 
        phone: p.phone || '', 
        active: true,
        group_name: groupName.trim() || null
    }));

    try {
      await Participant.bulkCreate(participantsToCreate);
      alert(`ייבוא מהיר הושלם! ${participantsToCreate.length} משתתפים נוספו בהצלחה.`);
      onComplete();
    } catch (err) {
      console.error("Bulk create from paste failed:", err);
      setError("הייבוא המהיר נכשל. ייתכן שישנה מגבלה על כמות הנתונים או בעיית הרשאות. נסה להדביק פחות שורות (עד 100).");
    } finally {
      setIsProcessing(false);
    }
  };

  const ModalWrapper = motion.div;

  return (
    <ModalWrapper
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="w-full max-w-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <Card className="bg-white dark:bg-slate-800 shadow-2xl border dark:border-slate-700 rounded-xl">
          <CardHeader className="flex flex-row items-center justify-between pb-4 border-b dark:border-slate-700">
            <CardTitle className="text-xl font-semibold text-slate-800 dark:text-white flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-500"/>
                הדבקה מהירה
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200">
              <X className="w-5 h-5" />
            </Button>
          </CardHeader>
          <CardContent className="p-6 space-y-5">
            {!parsedParticipants ? (
              <>
                <div className="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-xl p-6 text-center">
                  <ClipboardPaste className="w-10 h-10 text-slate-400 dark:text-slate-500 mx-auto mb-3" />
                  <p className="text-base font-medium text-slate-700 dark:text-slate-200 mb-1">העתק נתונים מאקסל והדבק כאן</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    הייבוא ישלח את כל הנתונים במכה אחת.
                  </p>
                </div>
                <Textarea
                  value={textList}
                  onChange={handleTextChange}
                  placeholder="יוסי כהן	yossi@email.com	050-1234567&#10;שרה לוי	sara@email.com&#10;דוד יוסף&#10;... (אלפי שורות)"
                  rows={8}
                  className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200 dark:placeholder-slate-400 focus:ring-blue-500 dark:focus:ring-blue-400"
                />
                
                <div className="space-y-1.5">
                  <Label htmlFor="paste_group_name_participant" className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center">
                    <Users className="w-4 h-4 ml-2 opacity-70" />
                    שייך לקבוצה (אופציונלי)
                  </Label>
                  <Input
                    id="paste_group_name_participant"
                    value={groupName}
                    onChange={(e) => setGroupName(e.target.value)}
                    placeholder="הכנס שם קבוצה"
                    className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200"
                  />
                </div>
                
                <Button onClick={processList} disabled={isProcessing || !textList.trim()} className="w-full bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white">
                  {isProcessing ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Zap className="w-4 h-4 mr-2" />}
                  עבד רשימה
                </Button>
              </>
            ) : (
              <>
                <div className="p-3 bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20 rounded-lg text-green-700 dark:text-green-300 flex items-center gap-2 text-sm">
                  <CheckCircle className="w-5 h-5" />
                  נמצאו {parsedParticipants.length.toLocaleString()} משתתפים לייבוא.
                </div>

                {groupName.trim() && (
                  <div className="p-2.5 bg-blue-50 dark:bg-blue-500/10 border border-blue-200 dark:border-blue-500/20 rounded-lg">
                    <p className="text-xs text-blue-700 dark:text-blue-300 flex items-center gap-1">
                      <Users className="w-3.5 h-3.5" />
                      כל המשתתפים ישוייכו לקבוצה: <strong>{groupName.trim()}</strong>
                    </p>
                  </div>
                )}

                <div className="max-h-32 overflow-y-auto border dark:border-slate-600 rounded-md p-2 space-y-1 bg-slate-50 dark:bg-slate-700/30 text-xs">
                  {parsedParticipants.slice(0, 5).map((p, index) => (
                    <div key={index} className="bg-white/70 dark:bg-slate-700/50 p-1.5 rounded dark:text-slate-300 truncate">
                      {p.name} {p.email && `(${p.email})`} {p.phone && `[${p.phone}]`}
                    </div>
                  ))}
                  {parsedParticipants.length > 5 && (
                    <p className="text-center text-xs text-slate-500 dark:text-slate-400 mt-1">
                        ועוד {(parsedParticipants.length - 5).toLocaleString()} משתתפים...
                    </p>
                    )}
                </div>
              </>
            )}

            {error && (
              <div className="flex items-center gap-2 p-2.5 mt-2 bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 rounded-lg text-sm text-red-700 dark:text-red-400">
                <AlertTriangle className="w-4 h-4" />
                <p>{error}</p>
              </div>
            )}
          </CardContent>
          {parsedParticipants && (
            <CardFooter className="border-t dark:border-slate-700 p-4 flex gap-3">
                <Button
                    variant="outline"
                    onClick={() => { setParsedParticipants(null); setError(null); }}
                    className="flex-1 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
                >
                    חזור וערוך
                </Button>
                <Button
                    onClick={handleStart}
                    disabled={isProcessing}
                    className="flex-1 bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600 text-white"
                >
                    {isProcessing ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Play className="w-4 h-4 mr-2" />}
                    התחל ייבוא מהיר
                </Button>
            </CardFooter>
          )}
        </Card>
      </motion.div>
    </ModalWrapper>
  );
}