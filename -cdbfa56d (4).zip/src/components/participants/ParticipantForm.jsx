import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { X, Save, UserCircle, Mail, Phone, Users, CheckSquare, Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export default function ParticipantForm({ participant, onSave, onClose }) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    active: true,
    group_name: ""
  });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (participant) {
      setFormData({
        name: participant.name || "",
        email: participant.email || "",
        phone: participant.phone || "",
        active: participant.active ?? true,
        group_name: participant.group_name || ""
      });
    } else {
      // Reset for new participant
      setFormData({ name: "", email: "", phone: "", active: true, group_name: "" });
    }
  }, [participant]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSwitchChange = (checked) => {
    setFormData(prev => ({ ...prev, active: checked }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.name.trim()) {
      setIsSaving(true);
      try {
        await onSave(formData);
        // onClose(); // onSave should handle closing
      } catch (error) {
        console.error("Error in form submission:", error);
        // Potentially show an error message to the user
      } finally {
        setIsSaving(false);
      }
    }
  };

  const inputFields = [
    { id: "name", name: "name", label: "שם מלא *", type: "text", placeholder: "הכנס שם מלא", icon: UserCircle, required: true },
    { id: "email", name: "email", label: "כתובת מייל", type: "email", placeholder: "example@email.com", icon: Mail },
    { id: "phone", name: "phone", label: "מספר טלפון", type: "tel", placeholder: "050-1234567", icon: Phone },
    { id: "group_name", name: "group_name", label: "שם קבוצה", type: "text", placeholder: "לדוגמה: כיתה א', צוות מכירות", icon: Users },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="w-full max-w-lg"
        onClick={(e) => e.stopPropagation()} // Prevent closing when clicking inside
      >
        <Card className="bg-white dark:bg-slate-800 shadow-2xl border dark:border-slate-700 rounded-xl">
          <CardHeader className="flex flex-row items-center justify-between pb-4 border-b dark:border-slate-700">
            <CardTitle className="text-xl font-semibold text-slate-800 dark:text-white">
              {participant ? "עריכת משתתף" : "הוספת משתתף חדש"}
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200">
              <X className="w-5 h-5" />
            </Button>
          </CardHeader>
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-5">
              {inputFields.map(field => (
                <div key={field.id} className="space-y-1.5">
                  <Label htmlFor={field.id} className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center">
                    <field.icon className="w-4 h-4 ml-2 opacity-70" />
                    {field.label}
                  </Label>
                  <Input
                    id={field.id}
                    name={field.name}
                    type={field.type}
                    value={formData[field.name]}
                    onChange={handleChange}
                    placeholder={field.placeholder}
                    required={field.required}
                    className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200 dark:placeholder-slate-400 focus:ring-blue-500 dark:focus:ring-blue-400"
                  />
                </div>
              ))}

              <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-700/50 rounded-lg border dark:border-slate-600/50">
                <div className="flex items-center">
                    <CheckSquare className="w-4 h-4 ml-2 text-slate-600 dark:text-slate-400 opacity-70" />
                    <div>
                        <Label htmlFor="active" className="text-sm font-medium text-slate-700 dark:text-slate-300">משתתף פעיל</Label>
                        <p className="text-xs text-slate-500 dark:text-slate-400">האם המשתתף יוכל להשתתף בהגרלות</p>
                    </div>
                </div>
                <Switch
                  id="active"
                  checked={formData.active}
                  onCheckedChange={handleSwitchChange}
                  className="data-[state=checked]:bg-green-500 dark:data-[state=checked]:bg-green-500"
                />
              </div>

              <div className="flex gap-3 pt-3 border-t dark:border-slate-700">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  className="flex-1 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
                  disabled={isSaving}
                >
                  ביטול
                </Button>
                <Button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white"
                  disabled={isSaving || !formData.name.trim()}
                >
                  {isSaving ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-2" />
                  )}
                  {participant ? "עדכן פרטים" : "הוסף משתתף"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}