import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { X, Save, Gift, FileText, DollarSign, Loader2 } from "lucide-react"; // Added more icons
import { motion } from "framer-motion";

export default function PrizeForm({ prize, onSave, onClose }) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    value: ""
  });
  const [isSaving, setIsSaving] = useState(false);


  useEffect(() => {
    if (prize) {
      setFormData({
        name: prize.name || "",
        description: prize.description || "",
        value: prize.value === null || prize.value === undefined ? "" : String(prize.value)
      });
    } else {
      // Reset for new prize
      setFormData({ name: "", description: "", value: "" });
    }
  }, [prize]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.name.trim()) {
      setIsSaving(true);
      try {
        await onSave({
          ...formData,
          value: parseFloat(formData.value) || 0 
        });
        // onClose(); // onSave should handle this
      } catch (error) {
        console.error("Error saving prize:", error);
      } finally {
        setIsSaving(false);
      }
    }
  };

  const inputFields = [
    { id: "name", name: "name", label: "שם הפרס *", type: "text", placeholder: "הכנס שם פרס", icon: Gift, required: true },
    { id: "description", name: "description", label: "תיאור הפרס", type: "textarea", placeholder: "תיאור מפורט של הפרס (אופציונלי)", icon: FileText },
    { id: "value", name: "value", label: "ערך הפרס (₪)", type: "number", placeholder: "0", icon: DollarSign, min: "0", step: "0.01" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="w-full max-w-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <Card className="bg-white dark:bg-slate-800 shadow-2xl border dark:border-slate-700 rounded-xl">
          <CardHeader className="flex flex-row items-center justify-between pb-4 border-b dark:border-slate-700">
            <CardTitle className="text-xl font-semibold text-slate-800 dark:text-white">
              {prize ? "עריכת פרס" : "הוספת פרס חדש"}
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200">
              <X className="w-5 h-5" />
            </Button>
          </CardHeader>
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-5">
              {inputFields.map(field => (
                <div key={field.id} className="space-y-1.5">
                  <Label htmlFor={field.id} className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center">
                    <field.icon className="w-4 h-4 ml-2 opacity-70" />
                    {field.label}
                  </Label>
                  {field.type === "textarea" ? (
                    <Textarea
                      id={field.id}
                      name={field.name}
                      value={formData[field.name]}
                      onChange={handleChange}
                      placeholder={field.placeholder}
                      rows={3}
                      className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200 dark:placeholder-slate-400 focus:ring-amber-500 dark:focus:ring-amber-400"
                    />
                  ) : (
                    <Input
                      id={field.id}
                      name={field.name}
                      type={field.type}
                      value={formData[field.name]}
                      onChange={handleChange}
                      placeholder={field.placeholder}
                      required={field.required}
                      min={field.min}
                      step={field.step}
                      className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200 dark:placeholder-slate-400 focus:ring-amber-500 dark:focus:ring-amber-400"
                    />
                  )}
                </div>
              ))}

              <div className="flex gap-3 pt-3 border-t dark:border-slate-700">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  className="flex-1 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
                  disabled={isSaving}
                >
                  ביטול
                </Button>
                <Button
                  type="submit"
                  className="flex-1 bg-amber-600 hover:bg-amber-700 dark:bg-amber-500 dark:hover:bg-amber-600 text-white"
                  disabled={isSaving || !formData.name.trim()}
                >
                  {isSaving ? (
                     <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-2" />
                  )}
                  {prize ? "עדכן פרס" : "הוסף פרס"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}