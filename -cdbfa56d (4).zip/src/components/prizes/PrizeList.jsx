import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Edit2, Trash2, Gift, CheckCircle, Clock, MoreVertical, Tag } from "lucide-react";
import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function PrizeList({ prizes, isLoading, onEdit, onDelete }) {
  if (isLoading) {
    return (
      <div className="grid gap-4">
        {Array(3).fill(0).map((_, i) => (
          <Card key={i} className="glass-card p-0">
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 sm:gap-4">
                  <Skeleton className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg" />
                  <div className="space-y-1.5">
                    <Skeleton className="h-5 w-24 sm:w-40" />
                    <Skeleton className="h-4 w-32 sm:w-56" />
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Skeleton className="h-8 w-16 rounded-md" />
                  <Skeleton className="h-8 w-8 rounded-md" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (prizes.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass-card p-8 sm:p-12 text-center"
      >
        <Gift className="w-12 h-12 sm:w-16 sm:h-16 text-slate-400 dark:text-slate-500 mx-auto mb-4" />
        <h3 className="text-xl sm:text-2xl font-semibold text-slate-700 dark:text-slate-200 mb-2">אין פרסים ברשימה</h3>
        <p className="text-slate-500 dark:text-slate-400 text-sm sm:text-base">התחל על ידי הוספת פרסים או ייבוא מקובץ.</p>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={{
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: {
            staggerChildren: 0.05,
          },
        },
      }}
      className="grid gap-4"
    >
      {prizes.map((prize) => (
        <motion.div
          key={prize.id}
          variants={{
            hidden: { opacity: 0, y: 20 },
            visible: { opacity: 1, y: 0 },
          }}
          layout
        >
          <Card className="glass-card p-0 hover:shadow-xl dark:hover:shadow-slate-700/50 transition-all duration-300 overflow-hidden">
            <CardContent className="p-4 sm:p-5">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 sm:gap-4 flex-1 min-w-0">
                  <div className={`w-10 h-10 sm:w-11 sm:h-11 rounded-lg flex items-center justify-center shrink-0 border-2 ${
                    prize.drawn 
                      ? 'bg-amber-100 dark:bg-amber-800/50 border-amber-400 dark:border-amber-600' 
                      : 'bg-blue-100 dark:bg-blue-800/50 border-blue-400 dark:border-blue-600'
                  }`}>
                    {prize.drawn ? (
                      <CheckCircle className="w-5 h-5 sm:w-6 sm:h-6 text-amber-600 dark:text-amber-300" />
                    ) : (
                      <Clock className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600 dark:text-blue-300" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-base sm:text-lg font-semibold text-slate-800 dark:text-slate-100 truncate" title={prize.name}>
                      {prize.name}
                    </h3>
                    <div className="flex items-center gap-x-3 gap-y-1 mt-0.5 flex-wrap text-xs sm:text-sm">
                      {prize.description && (
                        <p className="text-slate-500 dark:text-slate-400 truncate" title={prize.description}>{prize.description}</p>
                      )}
                      {(prize.value || prize.value === 0) && (
                        <div className="flex items-center gap-1 text-green-600 dark:text-green-400 font-medium">
                           <Tag className="w-3.5 h-3.5" />
                          <span>₪{Number(prize.value).toLocaleString()}</span>
                        </div>
                      )}
                    </div>
                    {prize.winner_name && (
                      <div className="mt-1 text-xs sm:text-sm">
                        <span className="font-semibold text-blue-600 dark:text-blue-400">
                          🎉 זוכה: {prize.winner_name}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center gap-2 sm:gap-3 shrink-0">
                  <Badge 
                    variant={prize.drawn ? "default" : "secondary"} 
                    className={`hidden sm:inline-flex text-xs ${prize.drawn 
                      ? 'bg-amber-500/10 text-amber-700 dark:bg-amber-500/20 dark:text-amber-300 border-amber-500/30' 
                      : 'bg-blue-500/10 text-blue-600 dark:bg-blue-500/20 dark:text-blue-400 border-blue-500/30'}`}
                  >
                    {prize.drawn ? "הוגרל" : "זמין"}
                  </Badge>
                   <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 w-8 h-8 sm:w-9 sm:h-9"
                      >
                        <MoreVertical className="w-4 h-4 sm:w-5 sm:h-5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="dark:bg-slate-800 dark:border-slate-700">
                      <DropdownMenuItem onClick={() => onEdit(prize)} className="dark:hover:bg-slate-700">
                        <Edit2 className="w-4 h-4 ml-2" />
                        ערוך פרס
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => {
                          if (confirm(`האם אתה בטוח שברצונך למחוק את הפרס ${prize.name}?`)) {
                            onDelete(prize.id);
                          }
                        }}
                        className="text-red-600 dark:text-red-400 hover:!bg-red-50 dark:hover:!bg-red-500/20 focus:text-red-600 dark:focus:text-red-400"
                      >
                        <Trash2 className="w-4 h-4 ml-2" />
                        מחק פרס
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </motion.div>
  );
}