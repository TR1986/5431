
import React, { useState } from "react";
import { Prize } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { ClipboardPaste, X, CheckCircle, AlertTriangle, Loader2, Gift as GiftIcon } from "lucide-react";
import { motion } from "framer-motion";

export default function PrizePasteImport({ onClose, onComplete }) {
  const [textList, setTextList] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [parsedPrizes, setParsedPrizes] = useState(null);
  const [error, setError] = useState(null);

  const handleTextChange = (e) => {
    setTextList(e.target.value);
    setParsedPrizes(null);
    setError(null);
  };

  const processList = () => {
    if (!textList.trim()) {
      setError("תיבת הטקסט ריקה. אנא הדבק רשימת פרסים.");
      return;
    }
    
    setIsProcessing(true);
    setError(null);
    
    const lines = textList.split('\n').map(line => line.trim()).filter(line => line !== "");
    
    if (lines.length === 0) {
      setError("לא נמצאו נתונים תקינים ברשימה.");
      setParsedPrizes(null);
      setIsProcessing(false);
      return;
    }

    const prizesToImport = lines.map(line => {
      const columns = line.split(/\t|,/);
      const name = columns[0] ? columns[0].trim() : "";
      const description = columns[1] ? columns[1].trim() : "";
      const value = columns[2] ? parseFloat(columns[2].trim()) || 0 : 0;
      return { name, description, value };
    }).filter(p => p.name);

    if (prizesToImport.length === 0) {
      setError("לא נמצאו שמות פרסים תקינים. ודא שהעמודה הראשונה מכילה את שמות הפרסים.");
      setParsedPrizes(null);
      setIsProcessing(false);
      return;
    }

    setParsedPrizes(prizesToImport);
    setIsProcessing(false);
  };

  const handleImport = async () => {
    if (!parsedPrizes || parsedPrizes.length === 0) return;
    
    setIsProcessing(true);
    setError(null);
    
    const prizesToCreate = parsedPrizes.map(p => ({
      name: p.name,
      description: p.description || '', 
      value: p.value || 0, 
      drawn: false
    }));

    try {
      let successCount = 0;
      let errorCount = 0;
      const batchSize = 3; // Much smaller batches
      const delay = 4000; // Much longer delay - 4 seconds

      for (let i = 0; i < prizesToCreate.length; i += batchSize) {
          const batch = prizesToCreate.slice(i, i + batchSize);
          const promises = batch.map(prize => 
              Prize.create(prize)
                  .then(() => successCount++)
                  .catch(e => {
                      console.error("Error creating single prize in batch:", e, prize);
                      errorCount++;
                  })
          );
          await Promise.all(promises);

          if (i + batchSize < prizesToCreate.length) {
              await new Promise(resolve => setTimeout(resolve, delay));
          }
      }
      
      if (errorCount > 0) {
          alert(`ייבוא הושלם חלקית. ${successCount} פרסים יובאו, ${errorCount} נכשלו.`);
      } else {
          alert(`${successCount} פרסים יובאו בהצלחה!`);
      }
      onComplete();
    } catch (err) {
        console.error("Critical error during prize paste-import process:", err);
        setError("אירעה שגיאה קריטית במהלך הייבוא.");
    } finally {
      setIsProcessing(false);
    }
  };
  
  const ModalWrapper = motion.div;

  return (
    <ModalWrapper
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="w-full max-w-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <Card className="bg-white dark:bg-slate-800 shadow-2xl border dark:border-slate-700 rounded-xl">
          <CardHeader className="flex flex-row items-center justify-between pb-4 border-b dark:border-slate-700">
            <CardTitle className="text-xl font-semibold text-slate-800 dark:text-white flex items-center gap-2">
                <GiftIcon className="w-5 h-5 text-amber-600 dark:text-amber-400"/>
                הדבקת רשימת פרסים (מהיר)
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200">
              <X className="w-5 h-5" />
            </Button>
          </CardHeader>
          <CardContent className="p-6 space-y-5">
            {!parsedPrizes ? (
              <>
                <div className="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-xl p-6 text-center">
                  <ClipboardPaste className="w-10 h-10 text-slate-400 dark:text-slate-500 mx-auto mb-3" />
                  <p className="text-base font-medium text-slate-700 dark:text-slate-200 mb-1">העתק נתונים מאקסל והדבק כאן</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">סדר עמודות: שם, תיאור, ערך (אופציונלי).</p>
                </div>
                <Textarea
                  value={textList}
                  onChange={handleTextChange}
                  placeholder="אייפון 15	טלפון חדש	4000&#10;מחשב נייד Dell	מחשב גיימינג	7500&#10;שובר קניות"
                  rows={8}
                  className="dark:bg-slate-700 dark:border-slate-600 dark:text-slate-200 dark:placeholder-slate-400 focus:ring-amber-500 dark:focus:ring-amber-400"
                />
                <Button onClick={processList} disabled={isProcessing || !textList.trim()} className="w-full bg-amber-600 hover:bg-amber-700 dark:bg-amber-500 dark:hover:bg-amber-600 text-white">
                  {isProcessing ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : "עבד רשימה"}
                </Button>
              </>
            ) : (
              <>
                <div className="p-3 bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20 rounded-lg text-green-700 dark:text-green-300 flex items-center gap-2 text-sm">
                  <CheckCircle className="w-5 h-5" />
                  נמצאו {parsedPrizes.length} פרסים לייבוא.
                </div>

                <div className="max-h-48 overflow-y-auto border dark:border-slate-600 rounded-md p-2 space-y-1 bg-slate-50 dark:bg-slate-700/30 text-sm">
                  {parsedPrizes.slice(0, 10).map((p, index) => (
                    <div key={index} className="bg-white/70 dark:bg-slate-700/50 p-1.5 rounded text-xs dark:text-slate-300 truncate">
                      {p.name} {p.description && `(${p.description})`} {p.value > 0 && `[${p.value} ₪]`}
                    </div>
                  ))}
                  {parsedPrizes.length > 10 && (
                    <p className="text-center text-xs text-slate-500 dark:text-slate-400 mt-1">
                        ועוד {parsedPrizes.length - 10} פרסים...
                    </p>
                    )}
                </div>
              </>
            )}

            {error && (
              <div className="flex items-center gap-2 p-2.5 mt-2 bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 rounded-lg text-sm text-red-700 dark:text-red-400">
                <AlertTriangle className="w-4 h-4" />
                <p>{error}</p>
              </div>
            )}
          </CardContent>
          {parsedPrizes && (
            <CardFooter className="border-t dark:border-slate-700 p-4 flex gap-3">
                <Button
                    variant="outline"
                    onClick={() => { setParsedPrizes(null); setError(null); }}
                    className="flex-1 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
                    disabled={isProcessing}
                >
                    חזור וערוך
                </Button>
                <Button
                    onClick={handleImport}
                    disabled={isProcessing}
                    className="flex-1 bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600 text-white"
                >
                    {isProcessing ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : `יבא ${parsedPrizes.length} פרסים`}
                </Button>
            </CardFooter>
          )}
        </Card>
      </motion.div>
    </ModalWrapper>
  );
}
