
import React, { useState } from "react";
import { ExtractDataFromUploadedFile, UploadFile } from "@/api/integrations";
import { Prize } from "@/api/entities"; // Import Prize entity
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Upload, X, CheckCircle, AlertTriangle, FileSpreadsheet, Loader2, Gift as GiftIcon } from "lucide-react";
import { motion } from "framer-motion";

export default function PrizeImport({ onClose, onComplete }) {
  const [file, setFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedData, setExtractedData] = useState(null);
  const [error, setError] = useState(null);

  const handleFileSelect = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setExtractedData(null);
      setError(null);
    }
  };

  const processFile = async () => {
    if (!file) return;
    
    setIsProcessing(true);
    setError(null);
    setExtractedData(null);

    try {
      const { file_url } = await UploadFile({ file: file });
      if (!file_url) {
        throw new Error("File upload failed, no URL returned.");
      }

      const extractionResult = await ExtractDataFromUploadedFile({
        file_url: file_url,
        json_schema: {
          type: "array",
          items: {
            type: "object",
            properties: {
              name: { type: "string" },
              description: { type: "string", nullable: true },
              value: { type: "number", nullable: true }
            },
            required: ["name"]
          }
        }
      });

      if (extractionResult.status === "success" && extractionResult.output && Array.isArray(extractionResult.output)) {
        const validPrizes = extractionResult.output.filter(p => p.name && typeof p.name === 'string' && p.name.trim() !== "");
        if (validPrizes.length > 0) {
          setExtractedData(validPrizes);
        } else {
          setError("לא נמצאו שמות פרסים תקינים בקובץ.");
        }
      } else {
        console.error("Extraction failed:", extractionResult.details);
        setError(`שגיאה בעיבוד הקובץ: ${extractionResult.details || "פורמט לא נתמך או שגיאה פנימית."}`);
      }
    } catch (err) {
      console.error("Error processing file:", err);
      setError(`אירעה שגיאה בתהליך העיבוד: ${err.message}. נסה קובץ אחר או בדוק את הפורמט.`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleImport = async () => {
    if (!extractedData || extractedData.length === 0) {
      setError("אין נתונים תקינים לייבוא.");
      return;
    }
    
    setIsProcessing(true);
    setError(null);

    const prizesToCreate = extractedData.map(p => ({
      name: p.name,
      description: p.description || "",
      value: typeof p.value === 'number' ? p.value : 0,
      drawn: false
    }));

    try {
      let successCount = 0;
      let errorCount = 0;
      const batchSize = 3; // Much smaller batches - only 3 at a time
      const delay = 4000; // Much longer delay - 4 seconds

      for (let i = 0; i < prizesToCreate.length; i += batchSize) {
          const batch = prizesToCreate.slice(i, i + batchSize);
          const promises = batch.map(prize => 
              Prize.create(prize)
                  .then(() => successCount++)
                  .catch(e => {
                      console.error("Error creating single prize in batch:", e, prize);
                      errorCount++;
                  })
          );
          await Promise.all(promises);

          if (i + batchSize < prizesToCreate.length) {
              await new Promise(resolve => setTimeout(resolve, delay));
          }
      }
      
      if (errorCount > 0) {
          alert(`ייבוא הושלם חלקית. ${successCount} פרסים יובאו, ${errorCount} נכשלו.`);
      } else {
          alert(`${successCount} פרסים יובאו בהצלחה!`);
      }
      onComplete();
    } catch (err) {
      console.error("Critical error during prize import process:", err);
      setError("אירעה שגיאה קריטית במהלך הייבוא.");
    } finally {
      setIsProcessing(false);
    }
  };

  const ModalWrapper = motion.div;

  return (
    <ModalWrapper
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="w-full max-w-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <Card className="bg-white dark:bg-slate-800 shadow-2xl border dark:border-slate-700 rounded-xl">
          <CardHeader className="flex flex-row items-center justify-between pb-4 border-b dark:border-slate-700">
            <CardTitle className="text-xl font-semibold text-slate-800 dark:text-white flex items-center gap-2">
              <GiftIcon className="w-5 h-5 text-amber-600 dark:text-amber-400"/>
              ייבוא פרסים מאקסל/CSV
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200">
              <X className="w-5 h-5" />
            </Button>
          </CardHeader>
          <CardContent className="p-6 space-y-5">
            <div className="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-xl p-6 text-center hover:border-amber-500 dark:hover:border-amber-400 transition-colors">
              <Upload className="w-10 h-10 text-slate-400 dark:text-slate-500 mx-auto mb-3" />
               <Label htmlFor="prize-file-upload" className="text-base font-medium text-slate-700 dark:text-slate-200 cursor-pointer">
                בחר קובץ אקסל (xlsx) או CSV
              </Label>
              <Input
                id="prize-file-upload"
                type="file"
                accept=".xlsx,.csv"
                onChange={handleFileSelect}
                className="hidden"
              />
               {file ? (
                <p className="text-sm text-amber-600 dark:text-amber-400 mt-1">{file.name}</p>
              ) : (
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">גרור לכאן או לחץ לבחירה</p>
              )}
            </div>
            
            {!extractedData && file && (
                <Button onClick={processFile} disabled={isProcessing || !file} className="w-full bg-amber-600 hover:bg-amber-700 dark:bg-amber-500 dark:hover:bg-amber-600 text-white">
                  {isProcessing ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : "עבד קובץ"}
                </Button>
            )}

            {extractedData && (
              <>
                <div className="p-3 bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/20 rounded-lg text-green-700 dark:text-green-300 flex items-center gap-2 text-sm">
                  <CheckCircle className="w-5 h-5" />
                  נמצאו {extractedData.length} פרסים תקינים בקובץ.
                </div>
                <div className="max-h-32 overflow-y-auto border dark:border-slate-600 rounded-md p-2 space-y-1 bg-slate-50 dark:bg-slate-700/30 text-xs">
                  {extractedData.slice(0, 5).map((p, i) => (
                     <div key={i} className="bg-white/70 dark:bg-slate-700/50 p-1.5 rounded dark:text-slate-300 truncate">
                       {p.name} {p.description && `(${p.description.substring(0,20)}...)`} {typeof p.value === 'number' ? `[₪${p.value}]` : ''}
                    </div>
                  ))}
                  {extractedData.length > 5 && <p className="text-center text-xs text-slate-500 dark:text-slate-400 mt-1">ועוד {extractedData.length - 5}...</p>}
                </div>
              </>
            )}
            {error && (
                <div className="flex items-center gap-2 p-2.5 mt-2 bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/20 rounded-lg text-sm text-red-700 dark:text-red-400">
                  <AlertTriangle className="w-4 h-4" />
                  <p>{error}</p>
                </div>
            )}
          </CardContent>
           {extractedData && (
            <CardFooter className="border-t dark:border-slate-700 p-4 flex gap-3">
                <Button
                    variant="outline"
                    onClick={() => { setExtractedData(null); setError(null); setFile(null);}}
                    className="flex-1 dark:text-slate-300 dark:border-slate-600 dark:hover:bg-slate-700"
                    disabled={isProcessing}
                  >
                     נקה ובחר קובץ אחר
                  </Button>
              <Button
                onClick={handleImport}
                disabled={isProcessing || !extractedData || extractedData.length === 0}
                className="flex-1 bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600 text-white"
              >
                {isProcessing ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : `יבא ${extractedData.length} פרסים`}
              </Button>
            </CardFooter>
          )}
        </Card>
      </motion.div>
    </ModalWrapper>
  );
}
